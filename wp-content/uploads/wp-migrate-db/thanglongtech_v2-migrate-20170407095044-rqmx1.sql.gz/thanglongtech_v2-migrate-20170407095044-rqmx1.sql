# WordPress MySQL database migration
#
# Generated: Friday 7. April 2017 09:50 UTC
# Hostname: localhost
# Database: `thanglongtech_v2`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Một người bình luận WordPress', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2017-03-17 09:48:26', '2017-03-17 09:48:26', 'Xin chào, đây là một bình luận\nĐể bắt đầu với quản trị bình luận, chỉnh sửa hoặc xóa bình luận, vui lòng truy cập vào khu vực Bình luận trong trang quản trị.\nAvatar của người bình luận sử dụng <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=547 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/thietbidien', 'yes'),
(2, 'home', 'http://localhost/thietbidien', 'yes'),
(3, 'blogname', 'Website điện máy', 'yes'),
(4, 'blogdescription', 'Thiết kế bởi Vifonic.vn', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'cuongiview@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'j F, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:277:{s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:25:"(.?.+?)/orders(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&orders=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:28:"(.?.+?)/downloads(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&downloads=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:34:"(.?.+?)/payment-methods(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&payment-methods=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:40:"(.?.+?)/delete-payment-method(/(.*))?/?$";s:64:"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]";s:45:"(.?.+?)/set-default-payment-method(/(.*))?/?$";s:69:"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:9:"blocks/?$";s:26:"index.php?post_type=blocks";s:39:"blocks/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?post_type=blocks&feed=$matches[1]";s:34:"blocks/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?post_type=blocks&feed=$matches[1]";s:26:"blocks/page/([0-9]{1,})/?$";s:44:"index.php?post_type=blocks&paged=$matches[1]";s:24:"^wc-auth/v([1]{1})/(.*)?";s:63:"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]";s:22:"^wc-api/v([1-3]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-3]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:48:"(([^/]+/)*yeu-thich)(/(.*))?/page/([0-9]{1,})/?$";s:76:"index.php?pagename=$matches[1]&wishlist-action=$matches[4]&paged=$matches[5]";s:31:"(([^/]+/)*yeu-thich)(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&wishlist-action=$matches[4]";s:11:"san-pham/?$";s:27:"index.php?post_type=product";s:41:"san-pham/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:36:"san-pham/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:28:"san-pham/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:16:"featured_item/?$";s:33:"index.php?post_type=featured_item";s:46:"featured_item/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_type=featured_item&feed=$matches[1]";s:41:"featured_item/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_type=featured_item&feed=$matches[1]";s:33:"featured_item/page/([0-9]{1,})/?$";s:51:"index.php?post_type=featured_item&paged=$matches[1]";s:11:"sidebars/?$";s:27:"index.php?post_type=sidebar";s:41:"sidebars/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=sidebar&feed=$matches[1]";s:36:"sidebars/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=sidebar&feed=$matches[1]";s:28:"sidebars/page/([0-9]{1,})/?$";s:45:"index.php?post_type=sidebar&paged=$matches[1]";s:32:"blocks/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"blocks/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"blocks/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"blocks/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"blocks/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"blocks/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"blocks/(.+?)/embed/?$";s:39:"index.php?blocks=$matches[1]&embed=true";s:25:"blocks/(.+?)/trackback/?$";s:33:"index.php?blocks=$matches[1]&tb=1";s:45:"blocks/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?blocks=$matches[1]&feed=$matches[2]";s:40:"blocks/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?blocks=$matches[1]&feed=$matches[2]";s:33:"blocks/(.+?)/page/?([0-9]{1,})/?$";s:46:"index.php?blocks=$matches[1]&paged=$matches[2]";s:40:"blocks/(.+?)/comment-page-([0-9]{1,})/?$";s:46:"index.php?blocks=$matches[1]&cpage=$matches[2]";s:30:"blocks/(.+?)/wc-api(/(.*))?/?$";s:47:"index.php?blocks=$matches[1]&wc-api=$matches[3]";s:36:"blocks/.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:47:"blocks/.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:29:"blocks/(.+?)(?:/([0-9]+))?/?$";s:45:"index.php?blocks=$matches[1]&page=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:57:"block_categories/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?block_categories=$matches[1]&feed=$matches[2]";s:52:"block_categories/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?block_categories=$matches[1]&feed=$matches[2]";s:33:"block_categories/([^/]+)/embed/?$";s:49:"index.php?block_categories=$matches[1]&embed=true";s:45:"block_categories/([^/]+)/page/?([0-9]{1,})/?$";s:56:"index.php?block_categories=$matches[1]&paged=$matches[2]";s:27:"block_categories/([^/]+)/?$";s:38:"index.php?block_categories=$matches[1]";s:47:"danh-muc/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:42:"danh-muc/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:23:"danh-muc/(.+?)/embed/?$";s:44:"index.php?product_cat=$matches[1]&embed=true";s:35:"danh-muc/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:17:"danh-muc/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:48:"tu-khoa/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:43:"tu-khoa/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:24:"tu-khoa/([^/]+)/embed/?$";s:44:"index.php?product_tag=$matches[1]&embed=true";s:36:"tu-khoa/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:18:"tu-khoa/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:36:"san-pham/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"san-pham/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"san-pham/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"san-pham/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"san-pham/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"san-pham/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"san-pham/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:29:"san-pham/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:49:"san-pham/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:44:"san-pham/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:37:"san-pham/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:44:"san-pham/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:34:"san-pham/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?product=$matches[1]&wc-api=$matches[3]";s:40:"san-pham/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:51:"san-pham/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:33:"san-pham/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:25:"san-pham/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"san-pham/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"san-pham/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"san-pham/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"san-pham/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"san-pham/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:45:"product_variation/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"product_variation/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"product_variation/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"product_variation/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"product_variation/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"product_variation/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"product_variation/([^/]+)/embed/?$";s:50:"index.php?product_variation=$matches[1]&embed=true";s:38:"product_variation/([^/]+)/trackback/?$";s:44:"index.php?product_variation=$matches[1]&tb=1";s:46:"product_variation/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?product_variation=$matches[1]&paged=$matches[2]";s:53:"product_variation/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?product_variation=$matches[1]&cpage=$matches[2]";s:43:"product_variation/([^/]+)/wc-api(/(.*))?/?$";s:58:"index.php?product_variation=$matches[1]&wc-api=$matches[3]";s:49:"product_variation/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:60:"product_variation/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"product_variation/([^/]+)(?:/([0-9]+))?/?$";s:56:"index.php?product_variation=$matches[1]&page=$matches[2]";s:34:"product_variation/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"product_variation/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"product_variation/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"product_variation/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"product_variation/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"product_variation/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:45:"shop_order_refund/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"shop_order_refund/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"shop_order_refund/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"shop_order_refund/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"shop_order_refund/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"shop_order_refund/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"shop_order_refund/([^/]+)/embed/?$";s:50:"index.php?shop_order_refund=$matches[1]&embed=true";s:38:"shop_order_refund/([^/]+)/trackback/?$";s:44:"index.php?shop_order_refund=$matches[1]&tb=1";s:46:"shop_order_refund/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?shop_order_refund=$matches[1]&paged=$matches[2]";s:53:"shop_order_refund/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?shop_order_refund=$matches[1]&cpage=$matches[2]";s:43:"shop_order_refund/([^/]+)/wc-api(/(.*))?/?$";s:58:"index.php?shop_order_refund=$matches[1]&wc-api=$matches[3]";s:49:"shop_order_refund/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:60:"shop_order_refund/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"shop_order_refund/([^/]+)(?:/([0-9]+))?/?$";s:56:"index.php?shop_order_refund=$matches[1]&page=$matches[2]";s:34:"shop_order_refund/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"shop_order_refund/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"shop_order_refund/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"shop_order_refund/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"shop_order_refund/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"shop_order_refund/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:39:"featured_item/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:49:"featured_item/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:69:"featured_item/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"featured_item/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"featured_item/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"featured_item/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:28:"featured_item/(.+?)/embed/?$";s:46:"index.php?featured_item=$matches[1]&embed=true";s:32:"featured_item/(.+?)/trackback/?$";s:40:"index.php?featured_item=$matches[1]&tb=1";s:52:"featured_item/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?featured_item=$matches[1]&feed=$matches[2]";s:47:"featured_item/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?featured_item=$matches[1]&feed=$matches[2]";s:40:"featured_item/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?featured_item=$matches[1]&paged=$matches[2]";s:47:"featured_item/(.+?)/comment-page-([0-9]{1,})/?$";s:53:"index.php?featured_item=$matches[1]&cpage=$matches[2]";s:37:"featured_item/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?featured_item=$matches[1]&wc-api=$matches[3]";s:43:"featured_item/.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:54:"featured_item/.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:36:"featured_item/(.+?)(?:/([0-9]+))?/?$";s:52:"index.php?featured_item=$matches[1]&page=$matches[2]";s:63:"featured_item_category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:61:"index.php?featured_item_category=$matches[1]&feed=$matches[2]";s:58:"featured_item_category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:61:"index.php?featured_item_category=$matches[1]&feed=$matches[2]";s:39:"featured_item_category/([^/]+)/embed/?$";s:55:"index.php?featured_item_category=$matches[1]&embed=true";s:51:"featured_item_category/([^/]+)/page/?([0-9]{1,})/?$";s:62:"index.php?featured_item_category=$matches[1]&paged=$matches[2]";s:33:"featured_item_category/([^/]+)/?$";s:44:"index.php?featured_item_category=$matches[1]";s:58:"featured_item_tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:56:"index.php?featured_item_tag=$matches[1]&feed=$matches[2]";s:53:"featured_item_tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:56:"index.php?featured_item_tag=$matches[1]&feed=$matches[2]";s:34:"featured_item_tag/([^/]+)/embed/?$";s:50:"index.php?featured_item_tag=$matches[1]&embed=true";s:46:"featured_item_tag/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?featured_item_tag=$matches[1]&paged=$matches[2]";s:28:"featured_item_tag/([^/]+)/?$";s:39:"index.php?featured_item_tag=$matches[1]";s:36:"sidebars/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"sidebars/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"sidebars/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"sidebars/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"sidebars/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"sidebars/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"sidebars/([^/]+)/embed/?$";s:40:"index.php?sidebar=$matches[1]&embed=true";s:29:"sidebars/([^/]+)/trackback/?$";s:34:"index.php?sidebar=$matches[1]&tb=1";s:49:"sidebars/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?sidebar=$matches[1]&feed=$matches[2]";s:44:"sidebars/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?sidebar=$matches[1]&feed=$matches[2]";s:37:"sidebars/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?sidebar=$matches[1]&paged=$matches[2]";s:44:"sidebars/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?sidebar=$matches[1]&cpage=$matches[2]";s:34:"sidebars/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?sidebar=$matches[1]&wc-api=$matches[3]";s:40:"sidebars/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:51:"sidebars/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:33:"sidebars/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?sidebar=$matches[1]&page=$matches[2]";s:25:"sidebars/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"sidebars/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"sidebars/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"sidebars/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"sidebars/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"sidebars/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=2&cpage=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:25:"([^/]+)/wc-api(/(.*))?/?$";s:45:"index.php?name=$matches[1]&wc-api=$matches[3]";s:31:"[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:36:"contact-form-7/wp-contact-form-7.php";i:1;s:53:"nextend-facebook-connect/nextend-facebook-connect.php";i:2;s:49:"nextend-google-connect/nextend-google-connect.php";i:3;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:4;s:27:"woocommerce/woocommerce.php";i:5;s:27:"woosidebars/woosidebars.php";i:6;s:31:"wp-migrate-db/wp-migrate-db.php";i:7;s:34:"yith-woocommerce-wishlist/init.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '7', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'flatsome', 'yes'),
(41, 'stylesheet', 'flatsome', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:5:{i:1;a:0:{}i:2;a:3:{s:5:"title";s:10:"Liên hệ";s:4:"text";s:253:"CÔNG TY TNHH KỸ THUẬT THƯƠNG MẠI AN CHẮC THẮNG<br>\r\nĐịa chỉ : 33/16 Quốc Hương, P.Thảo Điền, Q.2, TPHCM<br>\r\nĐiện thoại : 08 - 3519 4183<br>\r\nFax : 08 - 3519 4172<br>\r\nEmail : sale@actcol.com<br>\r\nWebsite : www.actcol.com";s:6:"filter";b:0;}i:3;a:3:{s:5:"title";s:8:"Facebook";s:4:"text";s:8:"Facebook";s:6:"filter";b:0;}i:4;a:3:{s:5:"title";s:5:"Video";s:4:"text";s:123:"<iframe width="100%" height="215" src="https://www.youtube.com/embed/ZYPpTWtQTFY" frameborder="0" allowfullscreen></iframe>";s:6:"filter";b:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '2', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:131:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;s:17:"edit_shop_webhook";b:1;s:17:"read_shop_webhook";b:1;s:19:"delete_shop_webhook";b:1;s:18:"edit_shop_webhooks";b:1;s:25:"edit_others_shop_webhooks";b:1;s:21:"publish_shop_webhooks";b:1;s:26:"read_private_shop_webhooks";b:1;s:20:"delete_shop_webhooks";b:1;s:28:"delete_private_shop_webhooks";b:1;s:30:"delete_published_shop_webhooks";b:1;s:27:"delete_others_shop_webhooks";b:1;s:26:"edit_private_shop_webhooks";b:1;s:28:"edit_published_shop_webhooks";b:1;s:25:"manage_shop_webhook_terms";b:1;s:23:"edit_shop_webhook_terms";b:1;s:25:"delete_shop_webhook_terms";b:1;s:25:"assign_shop_webhook_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:1:{s:4:"read";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop Manager";s:12:"capabilities";a:110:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_users";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:15:"unfiltered_html";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;s:17:"edit_shop_webhook";b:1;s:17:"read_shop_webhook";b:1;s:19:"delete_shop_webhook";b:1;s:18:"edit_shop_webhooks";b:1;s:25:"edit_others_shop_webhooks";b:1;s:21:"publish_shop_webhooks";b:1;s:26:"read_private_shop_webhooks";b:1;s:20:"delete_shop_webhooks";b:1;s:28:"delete_private_shop_webhooks";b:1;s:30:"delete_published_shop_webhooks";b:1;s:27:"delete_others_shop_webhooks";b:1;s:26:"edit_private_shop_webhooks";b:1;s:28:"edit_published_shop_webhooks";b:1;s:25:"manage_shop_webhook_terms";b:1;s:23:"edit_shop_webhook_terms";b:1;s:25:"delete_shop_webhook_terms";b:1;s:25:"assign_shop_webhook_terms";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'WPLANG', 'vi', 'yes'),
(95, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'sidebars_widgets', 'a:7:{s:19:"wp_inactive_widgets";a:0:{}s:12:"sidebar-main";a:4:{i:0;s:32:"woocommerce_product_categories-3";i:1;s:22:"woocommerce_products-3";i:2;s:23:"flatsome_recent_posts-2";i:3;s:6:"text-4";}s:16:"sidebar-footer-1";a:0:{}s:16:"sidebar-footer-2";a:4:{i:0;s:6:"text-2";i:1;s:10:"nav_menu-2";i:2;s:10:"nav_menu-3";i:3;s:6:"text-3";}s:12:"shop-sidebar";a:4:{i:0;s:32:"woocommerce_product_categories-2";i:1;s:26:"woocommerce_price_filter-2";i:2;s:22:"woocommerce_products-2";i:3;s:31:"woocommerce_product_tag_cloud-2";}s:15:"product-sidebar";a:0:{}s:13:"array_version";i:3;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_nav_menu', 'a:3:{i:2;a:2:{s:5:"title";s:10:"Thông tin";s:8:"nav_menu";i:20;}i:3;a:2:{s:5:"title";s:12:"Sản phẩm";s:8:"nav_menu";i:21;}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'cron', 'a:9:{i:1491559205;a:2:{s:30:"woocommerce_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1491562199;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1491585528;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1491601708;a:2:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1491601709;a:1:{s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1491609600;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1491644951;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1493899200;a:1:{s:25:"woocommerce_geoip_updater";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:7:"monthly";s:4:"args";a:0:{}s:8:"interval";i:2635200;}}}s:7:"version";i:2;}', 'yes'),
(106, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1489744288;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(124, 'can_compress_scripts', '1', 'no'),
(146, 'current_theme', 'Flatsome', 'yes'),
(147, 'theme_mods_flatsome', 'a:83:{i:0;b:0;s:17:"flatsome_fallback";i:0;s:20:"topbar_elements_left";a:1:{i:0;s:4:"html";}s:21:"topbar_elements_right";a:2:{i:0;s:9:"languages";i:1;s:6:"social";}s:20:"header_elements_left";a:0:{}s:21:"header_elements_right";a:3:{i:0;s:7:"account";i:1;s:7:"divider";i:2;s:4:"cart";}s:27:"header_elements_bottom_left";a:1:{i:0;s:3:"nav";}s:29:"header_elements_bottom_center";a:0:{}s:28:"header_elements_bottom_right";a:1:{i:0;s:6:"search";}s:27:"header_mobile_elements_left";a:1:{i:0;s:9:"menu-icon";}s:28:"header_mobile_elements_right";a:1:{i:0;s:4:"cart";}s:26:"header_mobile_elements_top";a:1:{i:0;s:4:"html";}s:14:"mobile_sidebar";a:5:{i:0;s:11:"search-form";i:1;s:3:"nav";i:2;s:7:"account";i:3;s:6:"html-2";i:4;s:6:"html-3";}s:14:"product_layout";N;s:23:"payment_icons_placement";s:6:"footer";s:14:"follow_twitter";s:10:"http://url";s:15:"follow_facebook";s:10:"http://url";s:16:"follow_instagram";s:10:"http://url";s:12:"follow_email";s:10:"your@email";s:16:"flatsome_version";i:3;s:7:"backups";N;s:9:"smof_init";s:31:"Fri, 17 Mar 2017 09:51:32 +0000";s:18:"custom_css_post_id";i:58;s:18:"nav_menu_locations";a:2:{s:7:"primary";i:12;s:14:"primary_mobile";i:12;}s:13:"type_headings";a:2:{s:11:"font-family";s:16:"Roboto Condensed";s:7:"variant";s:3:"700";}s:10:"type_texts";a:2:{s:11:"font-family";s:6:"Roboto";s:7:"variant";s:7:"regular";}s:9:"type_size";s:3:"100";s:8:"type_nav";a:2:{s:11:"font-family";s:16:"Roboto Condensed";s:7:"variant";s:3:"600";}s:8:"type_alt";a:2:{s:11:"font-family";s:6:"Roboto";s:7:"variant";s:7:"regular";}s:9:"site_logo";s:61:"http://localhost/flatsome/wp-content/uploads/2017/03/logo.png";s:10:"logo_width";s:3:"250";s:12:"logo_padding";s:1:"0";s:10:"grid_style";s:5:"grid1";s:15:"category_shadow";s:1:"0";s:21:"category_shadow_hover";s:1:"0";s:17:"add_to_cart_style";s:7:"outline";s:22:"sale_bubble_percentage";s:1:"1";s:13:"color_primary";s:7:"#EA3A3C";s:15:"color_secondary";s:7:"#8BC34A";s:11:"color_links";s:7:"#E74847";s:17:"color_links_hover";s:7:"#111111";s:20:"category_title_style";s:15:"featured-center";s:27:"category_header_transparent";s:1:"0";s:15:"breadcrumb_size";s:5:"small";s:17:"header_top_height";s:2:"30";s:9:"topbar_bg";s:7:"#EEEEEE";s:17:"nav_height_bottom";s:2:"24";s:25:"category_row_count_tablet";s:1:"3";s:11:"topbar_left";s:51:"<strong class="uppercase">Thăng Long Tech</strong>";s:25:"category_row_count_mobile";s:1:"2";s:13:"header_height";s:2:"91";s:8:"nav_size";s:0:"";s:16:"footer_left_text";s:136:"<div style="padding-top: 15px"><a href="http://vifonic.vn/" target="_blank">Thiết kế web</a> bởi <strong>Vifonic.vn</strong></div>";s:11:"preset_demo";s:15:"header-wide-nav";s:11:"topbar_show";s:1:"1";s:20:"header_bg_img_repeat";s:8:"repeat-x";s:17:"box_shadow_header";s:1:"0";s:13:"nav_uppercase";s:1:"1";s:27:"header_bg_transparent_shade";s:1:"0";s:20:"header_bottom_height";s:2:"44";s:15:"nav_position_bg";s:7:"#EA3A3C";s:20:"nav_uppercase_bottom";s:1:"1";s:18:"nav_position_color";s:4:"dark";s:12:"topbar_color";s:5:"light";s:15:"nav_size_bottom";s:6:"medium";s:21:"type_nav_bottom_color";s:7:"#FFFFFF";s:27:"type_nav_bottom_color_hover";s:7:"#FFEBA4";s:15:"dropdown_border";s:7:"#FFFFFF";s:17:"dropdown_nav_size";s:3:"100";s:13:"color_success";s:7:"#81D742";s:20:"header_height_sticky";s:2:"30";s:19:"sticky_logo_padding";s:1:"0";s:17:"nav_height_sticky";s:2:"50";s:13:"header_sticky";s:1:"0";s:17:"footer_2_bg_color";s:7:"#23282D";s:19:"footer_bottom_color";s:7:"#222222";s:11:"color_alert";s:7:"#EA3A3C";s:11:"color_texts";s:7:"#333333";s:19:"type_headings_color";s:7:"#111111";s:18:"category_row_count";s:1:"3";s:20:"product_box_category";s:1:"0";s:16:"type_size_mobile";s:3:"100";s:13:"disable_fonts";s:1:"0";}', 'yes'),
(148, 'theme_switched', '', 'yes'),
(149, 'widget_flatsome_recent_posts', 'a:2:{i:2;a:3:{s:5:"title";s:23:"Bài viết gần đây";s:6:"number";i:5;s:5:"image";s:2:"on";}s:12:"_multiwidget";i:1;}', 'yes'),
(150, 'widget_block_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(152, 'wpcf7', 'a:2:{s:7:"version";s:3:"4.7";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1489744777;s:7:"version";s:3:"4.7";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(153, 'woosidebars-version', '1.4.3', 'yes'),
(154, 'woocommerce_default_country', 'VN', 'yes'),
(155, 'woocommerce_allowed_countries', 'all', 'yes'),
(156, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(157, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(158, 'woocommerce_ship_to_countries', '', 'yes'),
(159, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(160, 'woocommerce_default_customer_address', 'geolocation', 'yes'),
(161, 'woocommerce_calc_taxes', 'no', 'yes'),
(162, 'woocommerce_demo_store', 'no', 'yes'),
(163, 'woocommerce_demo_store_notice', 'This is a demo store for testing purposes &mdash; no orders shall be fulfilled.', 'no'),
(164, 'woocommerce_currency', 'VND', 'yes'),
(165, 'woocommerce_currency_pos', 'right_space', 'yes'),
(166, 'woocommerce_price_thousand_sep', '.', 'yes'),
(167, 'woocommerce_price_decimal_sep', ',', 'yes'),
(168, 'woocommerce_price_num_decimals', '0', 'yes'),
(169, 'woocommerce_weight_unit', 'kg', 'yes'),
(170, 'woocommerce_dimension_unit', 'cm', 'yes'),
(171, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(172, 'woocommerce_review_rating_required', 'yes', 'no'),
(173, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(174, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(175, 'woocommerce_shop_page_id', '7', 'yes'),
(176, 'woocommerce_shop_page_display', '', 'yes'),
(177, 'woocommerce_category_archive_display', '', 'yes'),
(178, 'woocommerce_default_catalog_orderby', 'menu_order', 'yes'),
(179, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(180, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(181, 'shop_catalog_image_size', 'a:3:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";i:1;}', 'yes'),
(182, 'shop_single_image_size', 'a:3:{s:5:"width";s:3:"600";s:6:"height";s:3:"600";s:4:"crop";i:1;}', 'yes'),
(183, 'shop_thumbnail_image_size', 'a:3:{s:5:"width";s:2:"90";s:6:"height";s:2:"90";s:4:"crop";i:1;}', 'yes'),
(184, 'woocommerce_enable_lightbox', 'yes', 'yes'),
(185, 'woocommerce_manage_stock', 'yes', 'yes'),
(186, 'woocommerce_hold_stock_minutes', '60', 'no'),
(187, 'woocommerce_notify_low_stock', 'yes', 'no'),
(188, 'woocommerce_notify_no_stock', 'yes', 'no'),
(189, 'woocommerce_stock_email_recipient', 'cuongiview@gmail.com', 'no'),
(190, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(191, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(192, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(193, 'woocommerce_stock_format', '', 'yes'),
(194, 'woocommerce_file_download_method', 'force', 'no'),
(195, 'woocommerce_downloads_require_login', 'no', 'no'),
(196, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(197, 'woocommerce_prices_include_tax', 'no', 'yes'),
(198, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(199, 'woocommerce_shipping_tax_class', '', 'yes'),
(200, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(201, 'woocommerce_tax_classes', 'Reduced Rate\r\nZero Rate', 'yes'),
(202, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(203, 'woocommerce_tax_display_cart', 'excl', 'no'),
(204, 'woocommerce_price_display_suffix', '', 'yes'),
(205, 'woocommerce_tax_total_display', 'itemized', 'no'),
(206, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(207, 'woocommerce_shipping_cost_requires_address', 'no', 'no'),
(208, 'woocommerce_ship_to_destination', 'billing', 'no'),
(209, 'woocommerce_enable_coupons', 'yes', 'yes'),
(210, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(211, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(212, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(213, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(214, 'woocommerce_cart_page_id', '8', 'yes'),
(215, 'woocommerce_checkout_page_id', '9', 'yes'),
(216, 'woocommerce_terms_page_id', '', 'no'),
(217, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(218, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(219, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(220, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(221, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(222, 'woocommerce_myaccount_page_id', '10', 'yes'),
(223, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no'),
(224, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(225, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'),
(226, 'woocommerce_registration_generate_username', 'yes', 'no'),
(227, 'woocommerce_registration_generate_password', 'no', 'no'),
(228, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(229, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(230, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(231, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(232, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(233, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(234, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(235, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(236, 'woocommerce_email_from_name', 'Shop Thực Phẩm 2', 'no'),
(237, 'woocommerce_email_from_address', 'cuongiview@gmail.com', 'no'),
(238, 'woocommerce_email_header_image', '', 'no'),
(239, 'woocommerce_email_footer_text', 'Shop Thực Phẩm 2 - Powered by WooCommerce', 'no') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(240, 'woocommerce_email_base_color', '#557da1', 'no'),
(241, 'woocommerce_email_background_color', '#f5f5f5', 'no'),
(242, 'woocommerce_email_body_background_color', '#fdfdfd', 'no'),
(243, 'woocommerce_email_text_color', '#505050', 'no'),
(244, 'woocommerce_api_enabled', 'yes', 'yes'),
(248, 'woocommerce_db_version', '2.6.14', 'yes'),
(249, 'woocommerce_version', '2.6.14', 'yes'),
(250, 'yit_recently_activated', 'a:0:{}', 'yes'),
(255, 'recently_activated', 'a:0:{}', 'yes'),
(256, 'woocommerce_admin_notices', 'a:0:{}', 'yes'),
(257, 'yith_wcwl_frontend_css_colors', 's:1159:"a:10:{s:15:"add_to_wishlist";a:3:{s:10:"background";s:7:"#333333";s:5:"color";s:7:"#FFFFFF";s:12:"border_color";s:7:"#333333";}s:21:"add_to_wishlist_hover";a:3:{s:10:"background";s:7:"#4F4F4F";s:5:"color";s:7:"#FFFFFF";s:12:"border_color";s:7:"#4F4F4F";}s:11:"add_to_cart";a:3:{s:10:"background";s:7:"#333333";s:5:"color";s:7:"#FFFFFF";s:12:"border_color";s:7:"#333333";}s:17:"add_to_cart_hover";a:3:{s:10:"background";s:7:"#4F4F4F";s:5:"color";s:7:"#FFFFFF";s:12:"border_color";s:7:"#4F4F4F";}s:14:"button_style_1";a:3:{s:10:"background";s:7:"#333333";s:5:"color";s:7:"#FFFFFF";s:12:"border_color";s:7:"#333333";}s:20:"button_style_1_hover";a:3:{s:10:"background";s:7:"#4F4F4F";s:5:"color";s:7:"#FFFFFF";s:12:"border_color";s:7:"#4F4F4F";}s:14:"button_style_2";a:3:{s:10:"background";s:7:"#FFFFFF";s:5:"color";s:7:"#858484";s:12:"border_color";s:7:"#c6c6c6";}s:20:"button_style_2_hover";a:3:{s:10:"background";s:7:"#4F4F4F";s:5:"color";s:7:"#FFFFFF";s:12:"border_color";s:7:"#4F4F4F";}s:14:"wishlist_table";a:3:{s:10:"background";s:7:"#FFFFFF";s:5:"color";s:7:"#6d6c6c";s:12:"border_color";s:7:"#FFFFFF";}s:7:"headers";a:1:{s:10:"background";s:7:"#F4F4F4";}}";', 'yes'),
(262, 'widget_woocommerce_widget_cart', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(263, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(264, 'widget_woocommerce_layered_nav', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(265, 'widget_woocommerce_price_filter', 'a:2:{i:2;a:1:{s:5:"title";s:15:"Lọc theo giá";}s:12:"_multiwidget";i:1;}', 'yes'),
(266, 'widget_woocommerce_product_categories', 'a:3:{i:2;a:7:{s:5:"title";s:23:"Danh mục sản phẩm";s:7:"orderby";s:4:"name";s:8:"dropdown";i:0;s:5:"count";i:0;s:12:"hierarchical";i:1;s:18:"show_children_only";i:0;s:10:"hide_empty";i:0;}i:3;a:7:{s:5:"title";s:23:"Danh mục sản phẩm";s:7:"orderby";s:5:"order";s:8:"dropdown";i:0;s:5:"count";i:0;s:12:"hierarchical";i:1;s:18:"show_children_only";i:0;s:10:"hide_empty";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(267, 'widget_woocommerce_product_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(268, 'widget_woocommerce_product_tag_cloud', 'a:2:{i:2;a:1:{s:5:"title";s:23:"Từ khóa sản phẩm";}s:12:"_multiwidget";i:1;}', 'yes'),
(269, 'widget_woocommerce_products', 'a:3:{i:2;a:7:{s:5:"title";s:24:"Sản phẩm giảm giá";s:6:"number";i:5;s:4:"show";s:6:"onsale";s:7:"orderby";s:4:"date";s:5:"order";s:4:"desc";s:9:"hide_free";i:0;s:11:"show_hidden";i:0;}i:3;a:7:{s:5:"title";s:24:"Sản phẩm nổi bật";s:6:"number";i:5;s:4:"show";s:0:"";s:7:"orderby";s:4:"date";s:5:"order";s:4:"desc";s:9:"hide_free";i:0;s:11:"show_hidden";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(270, 'widget_woocommerce_rating_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(271, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(272, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(273, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(274, 'widget_upsell_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(277, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(278, 'yith_wcwl_enabled', 'yes', 'yes'),
(279, 'yith_wcwl_wishlist_title', 'My wishlist on Shop Thực Phẩm 2', 'yes'),
(280, 'yith_wcwl_wishlist_page_id', '6', 'yes'),
(281, 'yith_wcwl_redirect_cart', 'no', 'yes'),
(282, 'yith_wcwl_remove_after_add_to_cart', 'yes', 'yes'),
(283, 'yith_wcwl_add_to_wishlist_text', 'Add to Wishlist', 'yes'),
(284, 'yith_wcwl_browse_wishlist_text', 'Browse Wishlist', 'yes'),
(285, 'yith_wcwl_already_in_wishlist_text', 'The product is already in the wishlist!', 'yes'),
(286, 'yith_wcwl_product_added_text', 'Product added!', 'yes'),
(287, 'yith_wcwl_add_to_cart_text', 'Add to Cart', 'yes'),
(288, 'yith_wcwl_price_show', 'yes', 'yes'),
(289, 'yith_wcwl_add_to_cart_show', 'yes', 'yes'),
(290, 'yith_wcwl_stock_show', 'yes', 'yes'),
(291, 'yith_wcwl_show_dateadded', 'no', 'yes'),
(292, 'yith_wcwl_repeat_remove_button', 'no', 'yes'),
(293, 'yith_wcwl_use_button', 'no', 'yes'),
(294, 'yith_wcwl_custom_css', '', 'yes'),
(295, 'yith_wcwl_frontend_css', 'yes', 'yes'),
(296, 'yith_wcwl_rounded_corners', 'yes', 'yes'),
(297, 'yith_wcwl_add_to_wishlist_icon', 'none', 'yes'),
(298, 'yith_wcwl_add_to_cart_icon', 'fa-shopping-cart', 'yes'),
(299, 'yith_wcwl_share_fb', 'yes', 'yes'),
(300, 'yith_wcwl_share_twitter', 'yes', 'yes'),
(301, 'yith_wcwl_share_pinterest', 'yes', 'yes'),
(302, 'yith_wcwl_share_googleplus', 'yes', 'yes'),
(303, 'yith_wcwl_share_email', 'yes', 'yes'),
(304, 'yith_wcwl_socials_title', 'My wishlist on Shop Thực Phẩm 2', 'yes'),
(305, 'yith_wcwl_socials_text', '', 'yes'),
(306, 'yith_wcwl_socials_image_url', '', 'yes'),
(307, 'yith_wfbt_enable_integration', 'yes', 'yes'),
(308, 'yith-wcwl-page-id', '6', 'yes'),
(309, 'yith_wcwl_version', '2.0.16', 'yes'),
(310, 'yith_wcwl_db_version', '2.0.0', 'yes'),
(312, 'yith_wcwl_general_videobox', 'a:7:{s:11:"plugin_name";s:25:"YITH WooCommerce Wishlist";s:18:"title_first_column";s:30:"Discover the Advanced Features";s:24:"description_first_column";s:89:"Upgrade to the PREMIUM VERSION\nof YITH WOOCOMMERCE WISHLIST to benefit from all features!";s:5:"video";a:3:{s:8:"video_id";s:9:"118797844";s:15:"video_image_url";s:117:"http://localhost/vifonic/shop_thuc_pham_2/wp-content/plugins/yith-woocommerce-wishlist//assets/images/video-thumb.jpg";s:17:"video_description";s:0:"";}s:19:"title_second_column";s:28:"Get Support and Pro Features";s:25:"description_second_column";s:205:"By purchasing the premium version of the plugin, you will take advantage of the advanced features of the product and you will get one year of free updates and support through our platform available 24h/24.";s:6:"button";a:2:{s:4:"href";s:78:"http://yithemes.com/themes/plugins/yith-woocommerce-wishlist/?refer_id=1030585";s:5:"title";s:28:"Get Support and Pro Features";}}', 'yes'),
(323, 'woocommerce_paypal-ec_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(324, 'woocommerce_stripe_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(325, 'woocommerce_paypal_settings', 'a:2:{s:7:"enabled";s:2:"no";s:5:"email";s:20:"cuongiview@gmail.com";}', 'yes'),
(326, 'woocommerce_cheque_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(327, 'woocommerce_bacs_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(328, 'woocommerce_cod_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(338, 'woocommerce_allow_tracking', 'no', 'yes'),
(363, 'woocommerce_permalinks', 'a:5:{s:13:"category_base";s:0:"";s:8:"tag_base";s:0:"";s:14:"attribute_base";s:0:"";s:12:"product_base";s:9:"/san-pham";s:22:"use_verbose_page_rules";b:1;}', 'yes'),
(369, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(481, 'product_cat_children', 'a:0:{}', 'yes'),
(509, 'category_children', 'a:0:{}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=802 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'page-blank.php'),
(4, 5, '_form', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n\n[submit "Send"]'),
(5, 5, '_mail', 'a:8:{s:7:"subject";s:37:"Shop Thực Phẩm 2 "[your-subject]"";s:6:"sender";s:34:"[your-name] <cuongiview@gmail.com>";s:4:"body";s:200:"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Shop Thực Phẩm 2 (http://localhost/vifonic/shop_thuc_pham_2)";s:9:"recipient";s:20:"cuongiview@gmail.com";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'),
(6, 5, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:37:"Shop Thực Phẩm 2 "[your-subject]"";s:6:"sender";s:43:"Shop Thực Phẩm 2 <cuongiview@gmail.com>";s:4:"body";s:142:"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Shop Thực Phẩm 2 (http://localhost/vifonic/shop_thuc_pham_2)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:30:"Reply-To: cuongiview@gmail.com";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'),
(7, 5, '_messages', 'a:8:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:22:"The field is required.";s:16:"invalid_too_long";s:22:"The field is too long.";s:17:"invalid_too_short";s:23:"The field is too short.";}'),
(8, 5, '_additional_settings', NULL),
(9, 5, '_locale', 'vi'),
(10, 8, '_edit_lock', '1489745462:1'),
(11, 8, '_edit_last', '1'),
(12, 8, '_wp_page_template', 'default'),
(13, 9, '_edit_last', '1'),
(14, 9, '_wp_page_template', 'default'),
(15, 9, '_edit_lock', '1489745473:1'),
(16, 10, '_edit_last', '1'),
(17, 10, '_wp_page_template', 'default'),
(18, 10, '_edit_lock', '1489771730:1'),
(19, 7, '_edit_last', '1'),
(20, 7, '_wp_page_template', 'default'),
(21, 7, '_edit_lock', '1489771853:1'),
(22, 2, '_edit_lock', '1491220993:1'),
(23, 2, '_edit_last', '1'),
(24, 2, '_footer', 'normal'),
(25, 16, '_edit_last', '1'),
(26, 16, '_edit_lock', '1491213307:1'),
(27, 17, '_wp_attached_file', '2017/03/apple.jpg'),
(28, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:575;s:6:"height";i:675;s:4:"file";s:17:"2017/03/apple.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"apple-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"apple-256x300.jpg";s:5:"width";i:256;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"apple-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:17:"apple-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:17:"apple-575x600.jpg";s:5:"width";i:575;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(29, 16, '_visibility', 'visible'),
(30, 16, '_stock_status', 'instock'),
(31, 16, '_thumbnail_id', '127'),
(32, 16, 'wc_productdata_options', 'a:1:{i:0;a:8:{s:11:"_bubble_new";s:0:"";s:12:"_bubble_text";s:0:"";s:17:"_custom_tab_title";s:0:"";s:11:"_custom_tab";s:0:"";s:14:"_product_video";s:0:"";s:19:"_product_video_size";s:0:"";s:12:"_top_content";s:0:"";s:15:"_bottom_content";s:0:"";}}'),
(33, 16, 'total_sales', '0'),
(34, 16, '_downloadable', 'no'),
(35, 16, '_virtual', 'no'),
(36, 16, '_purchase_note', ''),
(37, 16, '_featured', 'no'),
(38, 16, '_weight', ''),
(39, 16, '_length', ''),
(40, 16, '_width', ''),
(41, 16, '_height', ''),
(42, 16, '_sku', ''),
(43, 16, '_product_attributes', 'a:0:{}'),
(44, 16, '_regular_price', '16000000'),
(45, 16, '_sale_price', '15000000'),
(46, 16, '_sale_price_dates_from', ''),
(47, 16, '_sale_price_dates_to', ''),
(48, 16, '_price', '15000000'),
(49, 16, '_sold_individually', ''),
(50, 16, '_manage_stock', 'no'),
(51, 16, '_backorders', 'no'),
(52, 16, '_stock', ''),
(53, 16, '_upsell_ids', 'a:0:{}'),
(54, 16, '_crosssell_ids', 'a:0:{}'),
(55, 16, '_product_version', '2.6.14'),
(56, 16, '_product_image_gallery', ''),
(57, 18, '_edit_last', '1'),
(58, 18, '_edit_lock', '1491213204:1'),
(59, 18, '_visibility', 'visible'),
(60, 18, '_stock_status', 'instock'),
(61, 18, '_thumbnail_id', '126'),
(62, 18, 'wc_productdata_options', 'a:1:{i:0;a:8:{s:11:"_bubble_new";s:0:"";s:12:"_bubble_text";s:0:"";s:17:"_custom_tab_title";s:0:"";s:11:"_custom_tab";s:0:"";s:14:"_product_video";s:0:"";s:19:"_product_video_size";s:0:"";s:12:"_top_content";s:0:"";s:15:"_bottom_content";s:0:"";}}'),
(63, 18, '_downloadable', 'no'),
(64, 18, '_virtual', 'no'),
(65, 18, '_purchase_note', ''),
(66, 18, '_featured', 'no'),
(67, 18, '_weight', ''),
(68, 18, '_length', ''),
(69, 18, '_width', ''),
(70, 18, '_height', ''),
(71, 18, '_product_attributes', 'a:0:{}'),
(72, 18, '_regular_price', '16000000'),
(73, 18, '_sale_price', '15000000'),
(74, 18, '_sale_price_dates_from', ''),
(75, 18, '_sale_price_dates_to', ''),
(76, 18, '_price', '15000000'),
(77, 18, '_sold_individually', ''),
(78, 18, '_manage_stock', 'no'),
(79, 18, '_backorders', 'no'),
(80, 18, '_stock', ''),
(81, 18, '_upsell_ids', 'a:0:{}'),
(82, 18, '_crosssell_ids', 'a:0:{}'),
(83, 18, '_product_version', '2.6.14'),
(84, 18, '_product_image_gallery', ''),
(88, 16, '_wc_rating_count', 'a:0:{}'),
(89, 16, '_wc_average_rating', '0'),
(90, 19, '_wp_attached_file', '2017/03/apple-iphone-5.jpg'),
(91, 19, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:1024;s:4:"file";s:26:"2017/03/apple-iphone-5.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"apple-iphone-5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"apple-iphone-5-234x300.jpg";s:5:"width";i:234;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"apple-iphone-5-768x983.jpg";s:5:"width";i:768;s:6:"height";i:983;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"apple-iphone-5-800x1024.jpg";s:5:"width";i:800;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:24:"apple-iphone-5-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:26:"apple-iphone-5-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:26:"apple-iphone-5-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(92, 18, 'total_sales', '0'),
(93, 18, '_sku', ''),
(94, 20, '_edit_last', '1'),
(95, 20, '_edit_lock', '1491213241:1'),
(96, 21, '_wp_attached_file', '2017/03/sam-sung.jpg'),
(97, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:450;s:6:"height";i:580;s:4:"file";s:20:"2017/03/sam-sung.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"sam-sung-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"sam-sung-233x300.jpg";s:5:"width";i:233;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"sam-sung-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:20:"sam-sung-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(98, 20, '_visibility', 'visible'),
(99, 20, '_stock_status', 'instock'),
(100, 20, '_thumbnail_id', '125'),
(101, 20, 'wc_productdata_options', 'a:1:{i:0;a:8:{s:11:"_bubble_new";s:0:"";s:12:"_bubble_text";s:0:"";s:17:"_custom_tab_title";s:0:"";s:11:"_custom_tab";s:0:"";s:14:"_product_video";s:0:"";s:19:"_product_video_size";s:0:"";s:12:"_top_content";s:0:"";s:15:"_bottom_content";s:0:"";}}'),
(102, 20, 'total_sales', '0'),
(103, 20, '_downloadable', 'no'),
(104, 20, '_virtual', 'no'),
(105, 20, '_purchase_note', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(106, 20, '_featured', 'no'),
(107, 20, '_weight', ''),
(108, 20, '_length', ''),
(109, 20, '_width', ''),
(110, 20, '_height', ''),
(111, 20, '_sku', ''),
(112, 20, '_product_attributes', 'a:0:{}'),
(113, 20, '_regular_price', ''),
(114, 20, '_sale_price', ''),
(115, 20, '_sale_price_dates_from', ''),
(116, 20, '_sale_price_dates_to', ''),
(117, 20, '_price', ''),
(118, 20, '_sold_individually', ''),
(119, 20, '_manage_stock', 'no'),
(120, 20, '_backorders', 'no'),
(121, 20, '_stock', ''),
(122, 20, '_upsell_ids', 'a:0:{}'),
(123, 20, '_crosssell_ids', 'a:0:{}'),
(124, 20, '_product_version', '2.6.14'),
(125, 20, '_product_image_gallery', ''),
(126, 18, '_wc_rating_count', 'a:0:{}'),
(127, 18, '_wc_average_rating', '0'),
(128, 20, '_wc_rating_count', 'a:0:{}'),
(129, 20, '_wc_average_rating', '0'),
(130, 22, '_edit_last', '1'),
(131, 22, '_edit_lock', '1491213246:1'),
(132, 23, '_wp_attached_file', '2017/03/blackberry.jpg'),
(133, 23, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:450;s:6:"height";i:580;s:4:"file";s:22:"2017/03/blackberry.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"blackberry-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"blackberry-233x300.jpg";s:5:"width";i:233;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:20:"blackberry-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:22:"blackberry-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(134, 22, '_visibility', 'visible'),
(135, 22, '_stock_status', 'instock'),
(136, 22, '_thumbnail_id', '126'),
(137, 22, 'wc_productdata_options', 'a:1:{i:0;a:8:{s:11:"_bubble_new";s:0:"";s:12:"_bubble_text";s:0:"";s:17:"_custom_tab_title";s:0:"";s:11:"_custom_tab";s:0:"";s:14:"_product_video";s:0:"";s:19:"_product_video_size";s:0:"";s:12:"_top_content";s:0:"";s:15:"_bottom_content";s:0:"";}}'),
(138, 22, 'total_sales', '0'),
(139, 22, '_downloadable', 'no'),
(140, 22, '_virtual', 'no'),
(141, 22, '_purchase_note', ''),
(142, 22, '_featured', 'no'),
(143, 22, '_weight', ''),
(144, 22, '_length', ''),
(145, 22, '_width', ''),
(146, 22, '_height', ''),
(147, 22, '_sku', ''),
(148, 22, '_product_attributes', 'a:0:{}'),
(149, 22, '_regular_price', '6000000'),
(150, 22, '_sale_price', ''),
(151, 22, '_sale_price_dates_from', ''),
(152, 22, '_sale_price_dates_to', ''),
(153, 22, '_price', '6000000'),
(154, 22, '_sold_individually', ''),
(155, 22, '_manage_stock', 'no'),
(156, 22, '_backorders', 'no'),
(157, 22, '_stock', ''),
(158, 22, '_upsell_ids', 'a:0:{}'),
(159, 22, '_crosssell_ids', 'a:0:{}'),
(160, 22, '_product_version', '2.6.14'),
(161, 22, '_product_image_gallery', ''),
(162, 24, '_edit_last', '1'),
(163, 24, '_edit_lock', '1491213249:1'),
(164, 25, '_wp_attached_file', '2017/03/ipad-mini.jpg'),
(165, 25, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:450;s:6:"height";i:580;s:4:"file";s:21:"2017/03/ipad-mini.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"ipad-mini-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"ipad-mini-233x300.jpg";s:5:"width";i:233;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"ipad-mini-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"ipad-mini-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(166, 24, '_visibility', 'visible'),
(167, 24, '_stock_status', 'instock'),
(168, 24, '_thumbnail_id', '124'),
(169, 24, 'wc_productdata_options', 'a:1:{i:0;a:8:{s:11:"_bubble_new";s:0:"";s:12:"_bubble_text";s:0:"";s:17:"_custom_tab_title";s:0:"";s:11:"_custom_tab";s:0:"";s:14:"_product_video";s:0:"";s:19:"_product_video_size";s:0:"";s:12:"_top_content";s:0:"";s:15:"_bottom_content";s:0:"";}}'),
(170, 24, 'total_sales', '0'),
(171, 24, '_downloadable', 'no'),
(172, 24, '_virtual', 'no'),
(173, 24, '_purchase_note', ''),
(174, 24, '_featured', 'no'),
(175, 24, '_weight', ''),
(176, 24, '_length', ''),
(177, 24, '_width', ''),
(178, 24, '_height', ''),
(179, 24, '_sku', ''),
(180, 24, '_product_attributes', 'a:0:{}'),
(181, 24, '_regular_price', ''),
(182, 24, '_sale_price', ''),
(183, 24, '_sale_price_dates_from', ''),
(184, 24, '_sale_price_dates_to', ''),
(185, 24, '_price', ''),
(186, 24, '_sold_individually', ''),
(187, 24, '_manage_stock', 'no'),
(188, 24, '_backorders', 'no'),
(189, 24, '_stock', ''),
(190, 24, '_upsell_ids', 'a:0:{}'),
(191, 24, '_crosssell_ids', 'a:0:{}'),
(192, 24, '_product_version', '2.6.14'),
(193, 24, '_product_image_gallery', ''),
(194, 26, '_edit_last', '1'),
(195, 26, '_edit_lock', '1491213097:1'),
(196, 27, '_wp_attached_file', '2017/03/laptop.jpg'),
(197, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:450;s:6:"height";i:580;s:4:"file";s:18:"2017/03/laptop.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"laptop-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"laptop-233x300.jpg";s:5:"width";i:233;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:16:"laptop-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:18:"laptop-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(198, 26, '_visibility', 'visible'),
(199, 26, '_stock_status', 'instock'),
(200, 26, '_thumbnail_id', '125'),
(201, 26, 'wc_productdata_options', 'a:1:{i:0;a:8:{s:11:"_bubble_new";s:0:"";s:12:"_bubble_text";s:0:"";s:17:"_custom_tab_title";s:0:"";s:11:"_custom_tab";s:0:"";s:14:"_product_video";s:0:"";s:19:"_product_video_size";s:0:"";s:12:"_top_content";s:0:"";s:15:"_bottom_content";s:0:"";}}'),
(202, 26, 'total_sales', '0'),
(203, 26, '_downloadable', 'no'),
(204, 26, '_virtual', 'no'),
(205, 26, '_purchase_note', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(206, 26, '_featured', 'no'),
(207, 26, '_weight', ''),
(208, 26, '_length', ''),
(209, 26, '_width', ''),
(210, 26, '_height', ''),
(211, 26, '_sku', ''),
(212, 26, '_product_attributes', 'a:0:{}'),
(213, 26, '_regular_price', '20000000'),
(214, 26, '_sale_price', '19000000'),
(215, 26, '_sale_price_dates_from', ''),
(216, 26, '_sale_price_dates_to', ''),
(217, 26, '_price', '19000000'),
(218, 26, '_sold_individually', ''),
(219, 26, '_manage_stock', 'no'),
(220, 26, '_backorders', 'no'),
(221, 26, '_stock', ''),
(222, 26, '_upsell_ids', 'a:0:{}'),
(223, 26, '_crosssell_ids', 'a:0:{}'),
(224, 26, '_product_version', '2.6.14'),
(225, 26, '_product_image_gallery', ''),
(226, 24, '_wc_rating_count', 'a:0:{}'),
(227, 24, '_wc_average_rating', '0'),
(228, 22, '_wc_rating_count', 'a:0:{}'),
(229, 22, '_wc_average_rating', '0'),
(230, 26, '_wc_rating_count', 'a:0:{}'),
(231, 26, '_wc_average_rating', '0'),
(232, 28, '_edit_last', '1'),
(233, 28, '_edit_lock', '1491213019:1'),
(234, 29, '_wp_attached_file', '2017/03/mac-book.jpg'),
(235, 29, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:450;s:6:"height";i:580;s:4:"file";s:20:"2017/03/mac-book.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"mac-book-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"mac-book-233x300.jpg";s:5:"width";i:233;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"mac-book-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:20:"mac-book-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(236, 28, '_visibility', 'visible'),
(237, 28, '_stock_status', 'instock'),
(238, 28, '_thumbnail_id', '126'),
(239, 28, 'wc_productdata_options', 'a:1:{i:0;a:8:{s:11:"_bubble_new";s:0:"";s:12:"_bubble_text";s:0:"";s:17:"_custom_tab_title";s:0:"";s:11:"_custom_tab";s:0:"";s:14:"_product_video";s:0:"";s:19:"_product_video_size";s:0:"";s:12:"_top_content";s:0:"";s:15:"_bottom_content";s:0:"";}}'),
(240, 28, 'total_sales', '0'),
(241, 28, '_downloadable', 'no'),
(242, 28, '_virtual', 'no'),
(243, 28, '_purchase_note', ''),
(244, 28, '_featured', 'no'),
(245, 28, '_weight', ''),
(246, 28, '_length', ''),
(247, 28, '_width', ''),
(248, 28, '_height', ''),
(249, 28, '_sku', ''),
(250, 28, '_product_attributes', 'a:0:{}'),
(251, 28, '_regular_price', '25000000'),
(252, 28, '_sale_price', '22000000'),
(253, 28, '_sale_price_dates_from', ''),
(254, 28, '_sale_price_dates_to', ''),
(255, 28, '_price', '22000000'),
(256, 28, '_sold_individually', ''),
(257, 28, '_manage_stock', 'no'),
(258, 28, '_backorders', 'no'),
(259, 28, '_stock', ''),
(260, 28, '_upsell_ids', 'a:0:{}'),
(261, 28, '_crosssell_ids', 'a:0:{}'),
(262, 28, '_product_version', '2.6.14'),
(263, 28, '_product_image_gallery', ''),
(264, 30, '_edit_last', '1'),
(265, 30, '_edit_lock', '1491213093:1'),
(266, 30, '_visibility', 'visible'),
(267, 30, '_stock_status', 'instock'),
(268, 30, '_thumbnail_id', '127'),
(269, 30, 'wc_productdata_options', 'a:1:{i:0;a:8:{s:11:"_bubble_new";s:0:"";s:12:"_bubble_text";s:0:"";s:17:"_custom_tab_title";s:0:"";s:11:"_custom_tab";s:0:"";s:14:"_product_video";s:0:"";s:19:"_product_video_size";s:0:"";s:12:"_top_content";s:0:"";s:15:"_bottom_content";s:0:"";}}'),
(270, 30, 'total_sales', '0'),
(271, 30, '_downloadable', 'no'),
(272, 30, '_virtual', 'no'),
(273, 30, '_purchase_note', ''),
(274, 30, '_featured', 'no'),
(275, 30, '_weight', ''),
(276, 30, '_length', ''),
(277, 30, '_width', ''),
(278, 30, '_height', ''),
(279, 30, '_sku', ''),
(280, 30, '_product_attributes', 'a:0:{}'),
(281, 30, '_regular_price', '4900000'),
(282, 30, '_sale_price', ''),
(283, 30, '_sale_price_dates_from', ''),
(284, 30, '_sale_price_dates_to', ''),
(285, 30, '_price', '4900000'),
(286, 30, '_sold_individually', ''),
(287, 30, '_manage_stock', 'no'),
(288, 30, '_backorders', 'no'),
(289, 30, '_stock', ''),
(290, 30, '_upsell_ids', 'a:0:{}'),
(291, 30, '_crosssell_ids', 'a:0:{}'),
(292, 30, '_product_version', '2.6.14'),
(293, 30, '_product_image_gallery', ''),
(294, 31, '_edit_last', '1'),
(295, 31, '_edit_lock', '1491213104:1'),
(296, 31, '_visibility', 'visible'),
(297, 31, '_stock_status', 'instock'),
(298, 31, '_thumbnail_id', '128'),
(299, 31, 'wc_productdata_options', 'a:1:{i:0;a:8:{s:11:"_bubble_new";s:0:"";s:12:"_bubble_text";s:0:"";s:17:"_custom_tab_title";s:0:"";s:11:"_custom_tab";s:0:"";s:14:"_product_video";s:0:"";s:19:"_product_video_size";s:0:"";s:12:"_top_content";s:0:"";s:15:"_bottom_content";s:0:"";}}'),
(300, 31, 'total_sales', '0'),
(301, 31, '_downloadable', 'no'),
(302, 31, '_virtual', 'no'),
(303, 31, '_purchase_note', ''),
(304, 31, '_featured', 'no'),
(305, 31, '_weight', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(306, 31, '_length', ''),
(307, 31, '_width', ''),
(308, 31, '_height', ''),
(309, 31, '_sku', ''),
(310, 31, '_product_attributes', 'a:0:{}'),
(311, 31, '_regular_price', ''),
(312, 31, '_sale_price', ''),
(313, 31, '_sale_price_dates_from', ''),
(314, 31, '_sale_price_dates_to', ''),
(315, 31, '_price', ''),
(316, 31, '_sold_individually', ''),
(317, 31, '_manage_stock', 'no'),
(318, 31, '_backorders', 'no'),
(319, 31, '_stock', ''),
(320, 31, '_upsell_ids', 'a:0:{}'),
(321, 31, '_crosssell_ids', 'a:0:{}'),
(322, 31, '_product_version', '2.6.14'),
(323, 31, '_product_image_gallery', ''),
(324, 30, '_wc_rating_count', 'a:0:{}'),
(325, 30, '_wc_average_rating', '0'),
(326, 28, '_wc_rating_count', 'a:0:{}'),
(327, 28, '_wc_average_rating', '0'),
(328, 31, '_wc_rating_count', 'a:0:{}'),
(329, 31, '_wc_average_rating', '0'),
(330, 10, '_footer', 'normal'),
(331, 6, '_edit_lock', '1489771764:1'),
(332, 6, '_edit_last', '1'),
(333, 6, '_footer', 'normal'),
(334, 6, '_wp_page_template', 'default'),
(335, 35, '_menu_item_type', 'post_type'),
(336, 35, '_menu_item_menu_item_parent', '0'),
(337, 35, '_menu_item_object_id', '2'),
(338, 35, '_menu_item_object', 'page'),
(339, 35, '_menu_item_target', ''),
(340, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(341, 35, '_menu_item_xfn', ''),
(342, 35, '_menu_item_url', ''),
(344, 36, '_menu_item_type', 'post_type'),
(345, 36, '_menu_item_menu_item_parent', '0'),
(346, 36, '_menu_item_object_id', '7'),
(347, 36, '_menu_item_object', 'page'),
(348, 36, '_menu_item_target', ''),
(349, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(350, 36, '_menu_item_xfn', ''),
(351, 36, '_menu_item_url', ''),
(353, 37, '_menu_item_type', 'taxonomy'),
(354, 37, '_menu_item_menu_item_parent', '36'),
(355, 37, '_menu_item_object_id', '6'),
(356, 37, '_menu_item_object', 'product_cat'),
(357, 37, '_menu_item_target', ''),
(358, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(359, 37, '_menu_item_xfn', ''),
(360, 37, '_menu_item_url', ''),
(362, 38, '_menu_item_type', 'taxonomy'),
(363, 38, '_menu_item_menu_item_parent', '37'),
(364, 38, '_menu_item_object_id', '9'),
(365, 38, '_menu_item_object', 'product_cat'),
(366, 38, '_menu_item_target', ''),
(367, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(368, 38, '_menu_item_xfn', ''),
(369, 38, '_menu_item_url', ''),
(371, 39, '_menu_item_type', 'taxonomy'),
(372, 39, '_menu_item_menu_item_parent', '37'),
(373, 39, '_menu_item_object_id', '7'),
(374, 39, '_menu_item_object', 'product_cat'),
(375, 39, '_menu_item_target', ''),
(376, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(377, 39, '_menu_item_xfn', ''),
(378, 39, '_menu_item_url', ''),
(380, 40, '_menu_item_type', 'taxonomy'),
(381, 40, '_menu_item_menu_item_parent', '37'),
(382, 40, '_menu_item_object_id', '8'),
(383, 40, '_menu_item_object', 'product_cat'),
(384, 40, '_menu_item_target', ''),
(385, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(386, 40, '_menu_item_xfn', ''),
(387, 40, '_menu_item_url', ''),
(389, 41, '_menu_item_type', 'taxonomy'),
(390, 41, '_menu_item_menu_item_parent', '36'),
(391, 41, '_menu_item_object_id', '11'),
(392, 41, '_menu_item_object', 'product_cat'),
(393, 41, '_menu_item_target', ''),
(394, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(395, 41, '_menu_item_xfn', ''),
(396, 41, '_menu_item_url', ''),
(398, 42, '_menu_item_type', 'taxonomy'),
(399, 42, '_menu_item_menu_item_parent', '36'),
(400, 42, '_menu_item_object_id', '10'),
(401, 42, '_menu_item_object', 'product_cat'),
(402, 42, '_menu_item_target', ''),
(403, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(404, 42, '_menu_item_xfn', ''),
(405, 42, '_menu_item_url', ''),
(407, 43, '_menu_item_type', 'custom'),
(408, 43, '_menu_item_menu_item_parent', '0'),
(409, 43, '_menu_item_object_id', '43'),
(410, 43, '_menu_item_object', 'custom'),
(411, 43, '_menu_item_target', ''),
(412, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(413, 43, '_menu_item_xfn', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(414, 43, '_menu_item_url', '#'),
(416, 44, '_menu_item_type', 'custom'),
(417, 44, '_menu_item_menu_item_parent', '0'),
(418, 44, '_menu_item_object_id', '44'),
(419, 44, '_menu_item_object', 'custom'),
(420, 44, '_menu_item_target', ''),
(421, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(422, 44, '_menu_item_xfn', ''),
(423, 44, '_menu_item_url', '#'),
(443, 47, '_wp_trash_meta_status', 'publish'),
(444, 47, '_wp_trash_meta_time', '1489772463'),
(445, 48, '_wp_attached_file', '2017/03/logo.png'),
(446, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:250;s:6:"height";i:75;s:4:"file";s:16:"2017/03/logo.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"logo-150x75.png";s:5:"width";i:150;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:14:"logo-90x75.png";s:5:"width";i:90;s:6:"height";i:75;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(449, 50, '_wp_trash_meta_status', 'publish'),
(450, 50, '_wp_trash_meta_time', '1489773115'),
(451, 51, '_menu_item_type', 'custom'),
(452, 51, '_menu_item_menu_item_parent', '41'),
(453, 51, '_menu_item_object_id', '51'),
(454, 51, '_menu_item_object', 'custom'),
(455, 51, '_menu_item_target', ''),
(456, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(457, 51, '_menu_item_xfn', ''),
(458, 51, '_menu_item_url', '#'),
(460, 52, '_menu_item_type', 'custom'),
(461, 52, '_menu_item_menu_item_parent', '41'),
(462, 52, '_menu_item_object_id', '52'),
(463, 52, '_menu_item_object', 'custom'),
(464, 52, '_menu_item_target', ''),
(465, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(466, 52, '_menu_item_xfn', ''),
(467, 52, '_menu_item_url', '#'),
(469, 53, '_menu_item_type', 'custom'),
(470, 53, '_menu_item_menu_item_parent', '41'),
(471, 53, '_menu_item_object_id', '53'),
(472, 53, '_menu_item_object', 'custom'),
(473, 53, '_menu_item_target', ''),
(474, 53, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(475, 53, '_menu_item_xfn', ''),
(476, 53, '_menu_item_url', '#'),
(478, 54, '_menu_item_type', 'custom'),
(479, 54, '_menu_item_menu_item_parent', '42'),
(480, 54, '_menu_item_object_id', '54'),
(481, 54, '_menu_item_object', 'custom'),
(482, 54, '_menu_item_target', ''),
(483, 54, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(484, 54, '_menu_item_xfn', ''),
(485, 54, '_menu_item_url', '#'),
(487, 55, '_menu_item_type', 'custom'),
(488, 55, '_menu_item_menu_item_parent', '42'),
(489, 55, '_menu_item_object_id', '55'),
(490, 55, '_menu_item_object', 'custom'),
(491, 55, '_menu_item_target', ''),
(492, 55, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(493, 55, '_menu_item_xfn', ''),
(494, 55, '_menu_item_url', '#'),
(496, 56, '_menu_item_type', 'custom'),
(497, 56, '_menu_item_menu_item_parent', '42'),
(498, 56, '_menu_item_object_id', '56'),
(499, 56, '_menu_item_object', 'custom'),
(500, 56, '_menu_item_target', ''),
(501, 56, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(502, 56, '_menu_item_xfn', ''),
(503, 56, '_menu_item_url', '#'),
(505, 57, '_wp_trash_meta_status', 'publish'),
(506, 57, '_wp_trash_meta_time', '1489774019'),
(507, 16, '_wc_review_count', '0'),
(508, 60, '_wp_trash_meta_status', 'publish'),
(509, 60, '_wp_trash_meta_time', '1489807960'),
(510, 20, '_wc_review_count', '0'),
(511, 61, '_wp_trash_meta_status', 'publish'),
(512, 61, '_wp_trash_meta_time', '1489815529'),
(513, 62, '_wp_attached_file', '2017/03/xiaomi.jpg'),
(514, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:920;s:6:"height";i:489;s:4:"file";s:18:"2017/03/xiaomi.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"xiaomi-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"xiaomi-300x159.jpg";s:5:"width";i:300;s:6:"height";i:159;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"xiaomi-768x408.jpg";s:5:"width";i:768;s:6:"height";i:408;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:16:"xiaomi-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:18:"xiaomi-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:18:"xiaomi-600x489.jpg";s:5:"width";i:600;s:6:"height";i:489;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(515, 63, '_wp_attached_file', '2017/03/banner-1.jpg'),
(516, 63, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:992;s:6:"height";i:420;s:4:"file";s:20:"2017/03/banner-1.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"banner-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"banner-1-300x127.jpg";s:5:"width";i:300;s:6:"height";i:127;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"banner-1-768x325.jpg";s:5:"width";i:768;s:6:"height";i:325;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"banner-1-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:20:"banner-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:20:"banner-1-600x420.jpg";s:5:"width";i:600;s:6:"height";i:420;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(522, 68, '_wp_attached_file', '2017/03/banner-DEAL.png'),
(523, 68, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:524;s:4:"file";s:23:"2017/03/banner-DEAL.png";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"banner-DEAL-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:22:"banner-DEAL-300x98.png";s:5:"width";i:300;s:6:"height";i:98;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:23:"banner-DEAL-768x252.png";s:5:"width";i:768;s:6:"height";i:252;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:24:"banner-DEAL-1024x335.png";s:5:"width";i:1024;s:6:"height";i:335;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"banner-DEAL-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"banner-DEAL-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:23:"banner-DEAL-600x524.png";s:5:"width";i:600;s:6:"height";i:524;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(526, 71, '_wp_attached_file', '2017/03/smart-watch.jpg'),
(527, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:450;s:6:"height";i:580;s:4:"file";s:23:"2017/03/smart-watch.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"smart-watch-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"smart-watch-233x300.jpg";s:5:"width";i:233;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"smart-watch-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:23:"smart-watch-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(528, 76, '_wp_trash_meta_status', 'publish'),
(529, 76, '_wp_trash_meta_time', '1489824087'),
(530, 78, '_wp_trash_meta_status', 'publish'),
(531, 78, '_wp_trash_meta_time', '1489824113'),
(532, 81, '_wp_trash_meta_status', 'publish'),
(533, 81, '_wp_trash_meta_time', '1489824982'),
(536, 84, '_wp_trash_meta_status', 'publish'),
(537, 84, '_wp_trash_meta_time', '1490121139'),
(538, 87, '_wp_trash_meta_status', 'publish'),
(539, 87, '_wp_trash_meta_time', '1491206252'),
(540, 88, '_wp_trash_meta_status', 'publish'),
(541, 88, '_wp_trash_meta_time', '1491206325'),
(542, 89, '_wp_trash_meta_status', 'publish'),
(543, 89, '_wp_trash_meta_time', '1491206462'),
(544, 90, '_wp_trash_meta_status', 'publish'),
(545, 90, '_wp_trash_meta_time', '1491206499'),
(546, 91, '_wp_trash_meta_status', 'publish'),
(547, 91, '_wp_trash_meta_time', '1491206549'),
(548, 92, '_wp_trash_meta_status', 'publish'),
(549, 92, '_wp_trash_meta_time', '1491206752'),
(550, 94, '_wp_trash_meta_status', 'publish') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(551, 94, '_wp_trash_meta_time', '1491206861'),
(552, 97, '_wp_trash_meta_status', 'publish'),
(553, 97, '_wp_trash_meta_time', '1491206889'),
(554, 98, '_wp_trash_meta_status', 'publish'),
(555, 98, '_wp_trash_meta_time', '1491206900'),
(556, 100, '_wp_trash_meta_status', 'publish'),
(557, 100, '_wp_trash_meta_time', '1491206909'),
(558, 101, '_wp_attached_file', '2017/04/slide.png'),
(559, 101, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1100;s:6:"height";i:330;s:4:"file";s:17:"2017/04/slide.png";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"slide-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:16:"slide-300x90.png";s:5:"width";i:300;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:17:"slide-768x230.png";s:5:"width";i:768;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:18:"slide-1024x307.png";s:5:"width";i:1024;s:6:"height";i:307;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"slide-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:17:"slide-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:11:"shop_single";a:4:{s:4:"file";s:17:"slide-600x330.png";s:5:"width";i:600;s:6:"height";i:330;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(560, 102, '_wp_attached_file', '2017/04/slider2.jpg'),
(561, 102, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1140;s:6:"height";i:400;s:4:"file";s:19:"2017/04/slider2.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"slider2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"slider2-300x105.jpg";s:5:"width";i:300;s:6:"height";i:105;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"slider2-768x269.jpg";s:5:"width";i:768;s:6:"height";i:269;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"slider2-1024x359.jpg";s:5:"width";i:1024;s:6:"height";i:359;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:17:"slider2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:19:"slider2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:19:"slider2-600x400.jpg";s:5:"width";i:600;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(563, 103, '_wp_trash_meta_status', 'publish'),
(564, 103, '_wp_trash_meta_time', '1491208318'),
(565, 107, '_wp_attached_file', '2017/04/1.png'),
(566, 107, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:390;s:6:"height";i:73;s:4:"file";s:13:"2017/04/1.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:12:"1-150x73.png";s:5:"width";i:150;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:12:"1-300x56.png";s:5:"width";i:300;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:11:"1-90x73.png";s:5:"width";i:90;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:12:"1-300x73.png";s:5:"width";i:300;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(567, 108, '_wp_attached_file', '2017/04/2.png'),
(568, 108, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:390;s:6:"height";i:73;s:4:"file";s:13:"2017/04/2.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:12:"2-150x73.png";s:5:"width";i:150;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:12:"2-300x56.png";s:5:"width";i:300;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:11:"2-90x73.png";s:5:"width";i:90;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:12:"2-300x73.png";s:5:"width";i:300;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(569, 109, '_wp_attached_file', '2017/04/3.png'),
(570, 109, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:390;s:6:"height";i:73;s:4:"file";s:13:"2017/04/3.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:12:"3-150x73.png";s:5:"width";i:150;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:12:"3-300x56.png";s:5:"width";i:300;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:11:"3-90x73.png";s:5:"width";i:90;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:12:"3-300x73.png";s:5:"width";i:300;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(571, 110, '_wp_attached_file', '2017/04/4.png'),
(572, 110, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:390;s:6:"height";i:73;s:4:"file";s:13:"2017/04/4.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:12:"4-150x73.png";s:5:"width";i:150;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:12:"4-300x56.png";s:5:"width";i:300;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:11:"4-90x73.png";s:5:"width";i:90;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:12:"4-300x73.png";s:5:"width";i:300;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(573, 114, '_wp_attached_file', '2017/04/5.png'),
(574, 114, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:390;s:6:"height";i:73;s:4:"file";s:13:"2017/04/5.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:12:"5-150x73.png";s:5:"width";i:150;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:12:"5-300x56.png";s:5:"width";i:300;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:11:"5-90x73.png";s:5:"width";i:90;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:12:"5-300x73.png";s:5:"width";i:300;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(575, 116, '_wp_trash_meta_status', 'publish'),
(576, 116, '_wp_trash_meta_time', '1491209264'),
(577, 118, '_wp_trash_meta_status', 'publish'),
(578, 118, '_wp_trash_meta_time', '1491209325'),
(579, 120, '_wp_trash_meta_status', 'publish'),
(580, 120, '_wp_trash_meta_time', '1491209420'),
(581, 121, '_wp_trash_meta_status', 'publish'),
(582, 121, '_wp_trash_meta_time', '1491209639'),
(583, 123, '_wp_attached_file', '2017/03/P1.jpg'),
(584, 123, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:300;s:4:"file";s:14:"2017/03/P1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"P1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:12:"P1-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(585, 124, '_wp_attached_file', '2017/03/P2.jpg'),
(586, 124, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:300;s:4:"file";s:14:"2017/03/P2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"P2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:12:"P2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(587, 125, '_wp_attached_file', '2017/03/P3.jpg'),
(588, 125, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:300;s:4:"file";s:14:"2017/03/P3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"P3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:12:"P3-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(589, 126, '_wp_attached_file', '2017/03/P4.jpg'),
(590, 126, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:300;s:4:"file";s:14:"2017/03/P4.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"P4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:12:"P4-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(591, 127, '_wp_attached_file', '2017/03/P6.jpg'),
(592, 127, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:300;s:4:"file";s:14:"2017/03/P6.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"P6-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:12:"P6-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(593, 128, '_wp_attached_file', '2017/03/P7.jpg'),
(594, 128, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:300;s:4:"file";s:14:"2017/03/P7.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"P7-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:12:"P7-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(595, 31, '_wp_old_slug', 'samsung-galaxy-5s'),
(596, 28, '_wp_old_slug', 'macbook-pro'),
(597, 30, '_wp_old_slug', 'apple-ipad'),
(598, 26, '_wp_old_slug', 'laptop-macbook-pro'),
(599, 24, '_wp_old_slug', 'apple-ipad-mini'),
(600, 18, '_wp_old_slug', 'apple-iphone-5'),
(601, 20, '_wp_old_slug', 'samsung-galaxy-s5'),
(602, 132, '_wp_trash_meta_status', 'publish'),
(603, 132, '_wp_trash_meta_time', '1491213696'),
(604, 134, '_wp_trash_meta_status', 'publish'),
(605, 134, '_wp_trash_meta_time', '1491214173'),
(606, 136, '_wp_trash_meta_status', 'publish'),
(607, 136, '_wp_trash_meta_time', '1491214374'),
(608, 137, '_wp_trash_meta_status', 'publish'),
(609, 137, '_wp_trash_meta_time', '1491214543'),
(610, 139, '_wp_trash_meta_status', 'publish'),
(611, 139, '_wp_trash_meta_time', '1491220933'),
(612, 2, '_thumbnail_id', ''),
(613, 143, '_wp_trash_meta_status', 'publish'),
(614, 143, '_wp_trash_meta_time', '1491221694'),
(615, 144, '_wp_trash_meta_status', 'publish'),
(616, 144, '_wp_trash_meta_time', '1491221766'),
(617, 147, '_wp_trash_meta_status', 'publish'),
(618, 147, '_wp_trash_meta_time', '1491221880'),
(619, 149, '_wp_trash_meta_status', 'publish'),
(620, 149, '_wp_trash_meta_time', '1491221896'),
(621, 151, '_wp_attached_file', '2017/04/thu-1.png'),
(622, 151, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:378;s:6:"height";i:535;s:4:"file";s:17:"2017/04/thu-1.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"thu-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"thu-1-212x300.png";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:15:"thu-1-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:17:"thu-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(623, 152, '_wp_attached_file', '2017/04/3706500.png'),
(624, 152, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:376;s:6:"height";i:536;s:4:"file";s:19:"2017/04/3706500.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"3706500-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:19:"3706500-210x300.png";s:5:"width";i:210;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:17:"3706500-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:19:"3706500-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(625, 153, '_wp_attached_file', '2017/04/5428271.png'),
(626, 153, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:378;s:6:"height";i:535;s:4:"file";s:19:"2017/04/5428271.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"5428271-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:19:"5428271-212x300.png";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:17:"5428271-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:19:"5428271-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(627, 154, '_wp_attached_file', '2017/04/thu-1-1.png'),
(628, 154, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:378;s:6:"height";i:535;s:4:"file";s:19:"2017/04/thu-1-1.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"thu-1-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:19:"thu-1-1-212x300.png";s:5:"width";i:212;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:17:"thu-1-1-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:19:"thu-1-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(629, 155, '_wp_attached_file', '2017/04/6090520.png'),
(630, 155, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:378;s:6:"height";i:537;s:4:"file";s:19:"2017/04/6090520.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"6090520-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:19:"6090520-211x300.png";s:5:"width";i:211;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:17:"6090520-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:19:"6090520-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(631, 158, '_menu_item_type', 'custom'),
(632, 158, '_menu_item_menu_item_parent', '0'),
(633, 158, '_menu_item_object_id', '158'),
(634, 158, '_menu_item_object', 'custom'),
(635, 158, '_menu_item_target', ''),
(636, 158, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(637, 158, '_menu_item_xfn', ''),
(638, 158, '_menu_item_url', '#'),
(640, 159, '_menu_item_type', 'custom'),
(641, 159, '_menu_item_menu_item_parent', '0'),
(642, 159, '_menu_item_object_id', '159'),
(643, 159, '_menu_item_object', 'custom'),
(644, 159, '_menu_item_target', ''),
(645, 159, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(646, 159, '_menu_item_xfn', ''),
(647, 159, '_menu_item_url', '#'),
(649, 160, '_menu_item_type', 'custom'),
(650, 160, '_menu_item_menu_item_parent', '0'),
(651, 160, '_menu_item_object_id', '160'),
(652, 160, '_menu_item_object', 'custom'),
(653, 160, '_menu_item_target', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(654, 160, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(655, 160, '_menu_item_xfn', ''),
(656, 160, '_menu_item_url', '#'),
(658, 161, '_menu_item_type', 'post_type'),
(659, 161, '_menu_item_menu_item_parent', '0'),
(660, 161, '_menu_item_object_id', '2'),
(661, 161, '_menu_item_object', 'page'),
(662, 161, '_menu_item_target', ''),
(663, 161, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(664, 161, '_menu_item_xfn', ''),
(665, 161, '_menu_item_url', ''),
(667, 162, '_menu_item_type', 'post_type'),
(668, 162, '_menu_item_menu_item_parent', '0'),
(669, 162, '_menu_item_object_id', '7'),
(670, 162, '_menu_item_object', 'page'),
(671, 162, '_menu_item_target', ''),
(672, 162, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(673, 162, '_menu_item_xfn', ''),
(674, 162, '_menu_item_url', ''),
(676, 163, '_menu_item_type', 'post_type'),
(677, 163, '_menu_item_menu_item_parent', '0'),
(678, 163, '_menu_item_object_id', '9'),
(679, 163, '_menu_item_object', 'page'),
(680, 163, '_menu_item_target', ''),
(681, 163, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(682, 163, '_menu_item_xfn', ''),
(683, 163, '_menu_item_url', ''),
(685, 164, '_menu_item_type', 'custom'),
(686, 164, '_menu_item_menu_item_parent', '0'),
(687, 164, '_menu_item_object_id', '164'),
(688, 164, '_menu_item_object', 'custom'),
(689, 164, '_menu_item_target', ''),
(690, 164, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(691, 164, '_menu_item_xfn', ''),
(692, 164, '_menu_item_url', '#'),
(694, 165, '_menu_item_type', 'custom'),
(695, 165, '_menu_item_menu_item_parent', '0'),
(696, 165, '_menu_item_object_id', '165'),
(697, 165, '_menu_item_object', 'custom'),
(698, 165, '_menu_item_target', ''),
(699, 165, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(700, 165, '_menu_item_xfn', ''),
(701, 165, '_menu_item_url', '#'),
(703, 166, '_menu_item_type', 'custom'),
(704, 166, '_menu_item_menu_item_parent', '0'),
(705, 166, '_menu_item_object_id', '166'),
(706, 166, '_menu_item_object', 'custom'),
(707, 166, '_menu_item_target', ''),
(708, 166, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(709, 166, '_menu_item_xfn', ''),
(710, 166, '_menu_item_url', '#'),
(712, 167, '_menu_item_type', 'taxonomy'),
(713, 167, '_menu_item_menu_item_parent', '0'),
(714, 167, '_menu_item_object_id', '6'),
(715, 167, '_menu_item_object', 'product_cat'),
(716, 167, '_menu_item_target', ''),
(717, 167, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(718, 167, '_menu_item_xfn', ''),
(719, 167, '_menu_item_url', ''),
(721, 168, '_menu_item_type', 'taxonomy'),
(722, 168, '_menu_item_menu_item_parent', '0'),
(723, 168, '_menu_item_object_id', '11'),
(724, 168, '_menu_item_object', 'product_cat'),
(725, 168, '_menu_item_target', ''),
(726, 168, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(727, 168, '_menu_item_xfn', ''),
(728, 168, '_menu_item_url', ''),
(730, 169, '_menu_item_type', 'taxonomy'),
(731, 169, '_menu_item_menu_item_parent', '0'),
(732, 169, '_menu_item_object_id', '13'),
(733, 169, '_menu_item_object', 'product_cat'),
(734, 169, '_menu_item_target', ''),
(735, 169, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(736, 169, '_menu_item_xfn', ''),
(737, 169, '_menu_item_url', ''),
(739, 170, '_menu_item_type', 'taxonomy'),
(740, 170, '_menu_item_menu_item_parent', '0'),
(741, 170, '_menu_item_object_id', '8'),
(742, 170, '_menu_item_object', 'product_cat'),
(743, 170, '_menu_item_target', ''),
(744, 170, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(745, 170, '_menu_item_xfn', ''),
(746, 170, '_menu_item_url', ''),
(748, 171, '_menu_item_type', 'taxonomy'),
(749, 171, '_menu_item_menu_item_parent', '0'),
(750, 171, '_menu_item_object_id', '7'),
(751, 171, '_menu_item_object', 'product_cat'),
(752, 171, '_menu_item_target', ''),
(753, 171, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(754, 171, '_menu_item_xfn', ''),
(755, 171, '_menu_item_url', ''),
(757, 172, '_menu_item_type', 'taxonomy'),
(758, 172, '_menu_item_menu_item_parent', '0'),
(759, 172, '_menu_item_object_id', '9'),
(760, 172, '_menu_item_object', 'product_cat'),
(761, 172, '_menu_item_target', ''),
(762, 172, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(763, 172, '_menu_item_xfn', ''),
(764, 172, '_menu_item_url', ''),
(766, 173, '_menu_item_type', 'custom') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(767, 173, '_menu_item_menu_item_parent', '0'),
(768, 173, '_menu_item_object_id', '173'),
(769, 173, '_menu_item_object', 'custom'),
(770, 173, '_menu_item_target', ''),
(771, 173, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(772, 173, '_menu_item_xfn', ''),
(773, 173, '_menu_item_url', '#'),
(775, 174, '_wp_trash_meta_status', 'publish'),
(776, 174, '_wp_trash_meta_time', '1491228641'),
(777, 176, '_wp_trash_meta_status', 'publish'),
(778, 176, '_wp_trash_meta_time', '1491228701'),
(779, 24, '_wc_review_count', '0'),
(780, 178, '_wp_trash_meta_status', 'publish'),
(781, 178, '_wp_trash_meta_time', '1491230609'),
(782, 179, '_wp_trash_meta_status', 'publish'),
(783, 179, '_wp_trash_meta_time', '1491230855'),
(784, 181, '_edit_last', '1'),
(785, 181, '_edit_lock', '1491231274:1'),
(786, 182, '_wp_attached_file', '2017/04/3.jpg'),
(787, 182, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:600;s:4:"file";s:13:"2017/04/3.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:13:"3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:13:"3-300x150.jpg";s:5:"width";i:300;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:13:"3-768x384.jpg";s:5:"width";i:768;s:6:"height";i:384;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:14:"3-1024x512.jpg";s:5:"width";i:1024;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:11:"3-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:13:"3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:13:"3-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(788, 181, '_thumbnail_id', '182'),
(791, 184, '_edit_last', '1'),
(792, 184, '_edit_lock', '1491231354:1'),
(793, 185, '_wp_attached_file', '2017/04/banner-plane.jpg'),
(794, 185, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1970;s:6:"height";i:1034;s:4:"file";s:24:"2017/04/banner-plane.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"banner-plane-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"banner-plane-300x157.jpg";s:5:"width";i:300;s:6:"height";i:157;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"banner-plane-768x403.jpg";s:5:"width";i:768;s:6:"height";i:403;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"banner-plane-1024x537.jpg";s:5:"width";i:1024;s:6:"height";i:537;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:22:"banner-plane-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:24:"banner-plane-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:24:"banner-plane-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(795, 184, '_thumbnail_id', '185'),
(798, 187, '_wp_trash_meta_status', 'publish'),
(799, 187, '_wp_trash_meta_time', '1491231692'),
(800, 188, '_wp_trash_meta_status', 'publish'),
(801, 188, '_wp_trash_meta_time', '1491234213') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2017-03-17 09:48:26', '2017-03-17 09:48:26', 'Chúc mừng đến với WordPress. Đây là bài viết đầu tiên của bạn. Hãy chỉnh sửa hay xóa bài viết này, và bắt đầu viết blog!', 'Chào tất cả mọi người!', '', 'publish', 'open', 'open', '', 'chao-moi-nguoi', '', '', '2017-03-17 09:48:26', '2017-03-17 09:48:26', '', 0, 'http://localhost/vifonic/shop_thuc_pham_2/?p=1', 0, 'post', '', 1),
(2, 1, '2017-03-17 09:48:26', '2017-03-17 09:48:26', '[gap height="20px"]\n\n[ux_banner_grid height="380"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="102" image_size="original" height="56.25%" margin="0px 0px -20px 0px"]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[row style="small" class="main-home-row"]\n\n[col span="3" span__sm="12"]\n\n[ux_sidebar]\n\n\n[/col]\n[col span="9" span__sm="12"]\n\n[title text="Thư ủy nhiệm" size="90"]\n\n[ux_gallery ids="151,152,153,154,155" style="normal" lightbox="false" type="slider" col_spacing="small" slider_nav_style="simple" slider_nav_position="outside" slider_bullets="true"]\n\n[title text="Sản phẩm nổi bật" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales"]\n\n[title text="Thiết bị nâng hạ" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales" show="onsale"]\n\n[title text="Dụng cụ cầm tay" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]\n\n[title text="Dụng cụ đo" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]\n\n[gap height="20px"]\n\n[title text="ĐỐI TÁC" size="90"]\n\n[ux_gallery ids="107,108,109,110,114" style="normal" lightbox="false" type="slider" col_spacing="small" slider_nav_style="simple" slider_nav_position="outside" slider_bullets="true" image_size="original" text_size="xsmall"]\n\n\n[/col]\n\n[/row]', 'Trang Chủ', '', 'publish', 'closed', 'open', '', 'trang-chu', '', '', '2017-04-03 21:02:39', '2017-04-03 14:02:39', '', 0, 'http://localhost/vifonic/shop_thuc_pham_2/?page_id=2', 0, 'page', '', 0),
(5, 1, '2017-03-17 09:59:36', '2017-03-17 09:59:36', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n\n[submit "Send"]\nShop Thực Phẩm 2 "[your-subject]"\n[your-name] <cuongiview@gmail.com>\nFrom: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Shop Thực Phẩm 2 (http://localhost/vifonic/shop_thuc_pham_2)\ncuongiview@gmail.com\nReply-To: [your-email]\n\n0\n0\n\nShop Thực Phẩm 2 "[your-subject]"\nShop Thực Phẩm 2 <cuongiview@gmail.com>\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Shop Thực Phẩm 2 (http://localhost/vifonic/shop_thuc_pham_2)\n[your-email]\nReply-To: cuongiview@gmail.com\n\n0\n0\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2017-03-17 09:59:36', '2017-03-17 09:59:36', '', 0, 'http://localhost/vifonic/shop_thuc_pham_2/?post_type=wpcf7_contact_form&p=5', 0, 'wpcf7_contact_form', '', 0),
(6, 1, '2017-03-17 10:02:33', '2017-03-17 10:02:33', '[yith_wcwl_wishlist]', 'Yêu thích', '', 'publish', 'closed', 'closed', '', 'yeu-thich', '', '', '2017-03-18 00:31:32', '2017-03-17 17:31:32', '', 0, 'http://localhost/vifonic/shop_thuc_pham_2/wishlist/', 0, 'page', '', 0),
(7, 1, '2017-03-17 17:07:07', '2017-03-17 10:07:07', '', 'Sản phẩm', '', 'publish', 'closed', 'closed', '', 'san-pham', '', '', '2017-03-18 00:30:53', '2017-03-17 17:30:53', '', 0, 'http://localhost/vifonic/shop_thuc_pham_2/shop/', 0, 'page', '', 0),
(8, 1, '2017-03-17 17:07:08', '2017-03-17 10:07:08', '[woocommerce_cart]', 'Giỏ hàng', '', 'publish', 'closed', 'closed', '', 'gio-hang', '', '', '2017-03-17 17:11:01', '2017-03-17 10:11:01', '', 0, 'http://localhost/vifonic/shop_thuc_pham_2/cart/', 0, 'page', '', 0),
(9, 1, '2017-03-17 17:07:08', '2017-03-17 10:07:08', '[woocommerce_checkout]', 'Thanh toán', '', 'publish', 'closed', 'closed', '', 'thanh-toan', '', '', '2017-03-17 17:11:13', '2017-03-17 10:11:13', '', 0, 'http://localhost/vifonic/shop_thuc_pham_2/checkout/', 0, 'page', '', 0),
(10, 1, '2017-03-17 17:07:08', '2017-03-17 10:07:08', '[woocommerce_my_account]', 'Tài khoản', '', 'publish', 'closed', 'closed', '', 'tai-khoan', '', '', '2017-03-18 00:31:10', '2017-03-17 17:31:10', '', 0, 'http://localhost/vifonic/shop_thuc_pham_2/my-account/', 0, 'page', '', 0),
(11, 1, '2017-03-17 17:11:01', '2017-03-17 10:11:01', '[woocommerce_cart]', 'Giỏ hàng', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-03-17 17:11:01', '2017-03-17 10:11:01', '', 8, 'http://localhost/vifonic/shop_thuc_pham_2/2017/03/17/8-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2017-03-17 17:11:13', '2017-03-17 10:11:13', '[woocommerce_checkout]', 'Thanh toán', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2017-03-17 17:11:13', '2017-03-17 10:11:13', '', 9, 'http://localhost/vifonic/shop_thuc_pham_2/2017/03/17/9-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2017-03-17 17:11:35', '2017-03-17 10:11:35', '[woocommerce_my_account]', 'Tài khoản của tôi', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2017-03-17 17:11:35', '2017-03-17 10:11:35', '', 10, 'http://localhost/vifonic/shop_thuc_pham_2/2017/03/17/10-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2017-03-17 17:11:45', '2017-03-17 10:11:45', '', 'Cửa hàng', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2017-03-17 17:11:45', '2017-03-17 10:11:45', '', 7, 'http://localhost/vifonic/shop_thuc_pham_2/2017/03/17/7-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2017-03-17 17:12:25', '2017-03-17 10:12:25', '', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-03-17 17:12:25', '2017-03-17 10:12:25', '', 2, 'http://localhost/vifonic/shop_thuc_pham_2/2017/03/17/2-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2017-03-18 00:21:11', '2017-03-17 17:21:11', '', 'Apple Iphone 6 16G', '', 'publish', 'open', 'closed', '', 'apple-iphone-6-16g', '', '', '2017-04-03 16:56:48', '2017-04-03 09:56:48', '', 0, 'http://localhost/flatsome/?post_type=product&#038;p=16', 0, 'product', '', 0),
(17, 1, '2017-03-18 00:20:36', '2017-03-17 17:20:36', '', 'apple', '', 'inherit', 'open', 'closed', '', 'apple', '', '', '2017-03-18 00:20:36', '2017-03-17 17:20:36', '', 16, 'http://localhost/flatsome/wp-content/uploads/2017/03/apple.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2017-03-18 00:21:20', '2017-03-17 17:21:20', '', 'Máy đánh bóng', '', 'publish', 'open', 'closed', '', 'may-danh-bong', '', '', '2017-04-03 16:55:44', '2017-04-03 09:55:44', '', 0, 'http://localhost/flatsome/product/apple-iphone-5/', 0, 'product', '', 0),
(19, 1, '2017-03-18 00:22:32', '2017-03-17 17:22:32', '', 'apple-iphone-5', '', 'inherit', 'open', 'closed', '', 'apple-iphone-5', '', '', '2017-03-18 00:22:32', '2017-03-17 17:22:32', '', 18, 'http://localhost/flatsome/wp-content/uploads/2017/03/apple-iphone-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(20, 1, '2017-03-18 00:23:48', '2017-03-17 17:23:48', '', 'Máy mài', '', 'publish', 'open', 'closed', '', 'may-mai-2', '', '', '2017-04-03 16:56:06', '2017-04-03 09:56:06', '', 0, 'http://localhost/flatsome/?post_type=product&#038;p=20', 0, 'product', '', 0),
(21, 1, '2017-03-18 00:23:37', '2017-03-17 17:23:37', '', 'sam-sung', '', 'inherit', 'open', 'closed', '', 'sam-sung', '', '', '2017-03-18 00:23:37', '2017-03-17 17:23:37', '', 20, 'http://localhost/flatsome/wp-content/uploads/2017/03/sam-sung.jpg', 0, 'attachment', 'image/jpeg', 0),
(22, 1, '2017-03-18 00:25:10', '2017-03-17 17:25:10', '', 'Blackberry Porsche', '', 'publish', 'open', 'closed', '', 'blackberry-porsche', '', '', '2017-04-03 16:55:14', '2017-04-03 09:55:14', '', 0, 'http://localhost/flatsome/?post_type=product&#038;p=22', 0, 'product', '', 0),
(23, 1, '2017-03-18 00:25:00', '2017-03-17 17:25:00', '', 'blackberry', '', 'inherit', 'open', 'closed', '', 'blackberry', '', '', '2017-03-18 00:25:00', '2017-03-17 17:25:00', '', 22, 'http://localhost/flatsome/wp-content/uploads/2017/03/blackberry.jpg', 0, 'attachment', 'image/jpeg', 0),
(24, 1, '2017-03-18 00:26:44', '2017-03-17 17:26:44', '', 'Máy khoan Nhật', '', 'publish', 'open', 'closed', '', 'may-khoan-nhat', '', '', '2017-04-03 16:55:01', '2017-04-03 09:55:01', '', 0, 'http://localhost/flatsome/?post_type=product&#038;p=24', 0, 'product', '', 0),
(25, 1, '2017-03-18 00:26:38', '2017-03-17 17:26:38', '', 'ipad-mini', '', 'inherit', 'open', 'closed', '', 'ipad-mini', '', '', '2017-03-18 00:26:38', '2017-03-17 17:26:38', '', 24, 'http://localhost/flatsome/wp-content/uploads/2017/03/ipad-mini.jpg', 0, 'attachment', 'image/jpeg', 0),
(26, 1, '2017-03-18 00:28:19', '2017-03-17 17:28:19', '', 'Bộ dụng cụ tone', '', 'publish', 'open', 'closed', '', 'bo-dung-cu-tone', '', '', '2017-04-03 16:53:53', '2017-04-03 09:53:53', '', 0, 'http://localhost/flatsome/?post_type=product&#038;p=26', 0, 'product', '', 0),
(27, 1, '2017-03-18 00:28:07', '2017-03-17 17:28:07', '', 'laptop', '', 'inherit', 'open', 'closed', '', 'laptop', '', '', '2017-03-18 00:28:07', '2017-03-17 17:28:07', '', 26, 'http://localhost/flatsome/wp-content/uploads/2017/03/laptop.jpg', 0, 'attachment', 'image/jpeg', 0),
(28, 1, '2017-03-18 00:29:23', '2017-03-17 17:29:23', '', 'Dụng cụ khoan', '', 'publish', 'open', 'closed', '', 'dung-cu-khoan', '', '', '2017-04-03 16:52:35', '2017-04-03 09:52:35', '', 0, 'http://localhost/flatsome/?post_type=product&#038;p=28', 0, 'product', '', 0),
(29, 1, '2017-03-18 00:29:11', '2017-03-17 17:29:11', '', 'mac-book', '', 'inherit', 'open', 'closed', '', 'mac-book', '', '', '2017-03-18 00:29:11', '2017-03-17 17:29:11', '', 28, 'http://localhost/flatsome/wp-content/uploads/2017/03/mac-book.jpg', 0, 'attachment', 'image/jpeg', 0),
(30, 1, '2017-03-18 00:29:58', '2017-03-17 17:29:58', '', 'Máy mài', '', 'publish', 'open', 'closed', '', 'may-mai', '', '', '2017-04-03 16:53:01', '2017-04-03 09:53:01', '', 0, 'http://localhost/flatsome/?post_type=product&#038;p=30', 0, 'product', '', 0),
(31, 1, '2017-03-18 00:30:25', '2017-03-17 17:30:25', '', 'Máy khoan', '', 'publish', 'open', 'closed', '', 'may-khoan', '', '', '2017-04-03 16:51:59', '2017-04-03 09:51:59', '', 0, 'http://localhost/flatsome/?post_type=product&#038;p=31', 0, 'product', '', 0),
(32, 1, '2017-03-18 00:30:53', '2017-03-17 17:30:53', '', 'Sản phẩm', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2017-03-18 00:30:53', '2017-03-17 17:30:53', '', 7, 'http://localhost/flatsome/2017/03/18/7-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2017-03-18 00:31:10', '2017-03-17 17:31:10', '[woocommerce_my_account]', 'Tài khoản', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2017-03-18 00:31:10', '2017-03-17 17:31:10', '', 10, 'http://localhost/flatsome/2017/03/18/10-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2017-03-18 00:31:32', '2017-03-17 17:31:32', '[yith_wcwl_wishlist]', 'Yêu thích', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2017-03-18 00:31:32', '2017-03-17 17:31:32', '', 6, 'http://localhost/flatsome/2017/03/18/6-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2017-03-18 00:39:29', '2017-03-17 17:39:29', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=35', 1, 'nav_menu_item', '', 0),
(36, 1, '2017-03-18 00:39:30', '2017-03-17 17:39:30', ' ', '', '', 'publish', 'closed', 'closed', '', '36', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=36', 3, 'nav_menu_item', '', 0),
(37, 1, '2017-03-18 00:39:30', '2017-03-17 17:39:30', ' ', '', '', 'publish', 'closed', 'closed', '', '37', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=37', 4, 'nav_menu_item', '', 0),
(38, 1, '2017-03-18 00:39:30', '2017-03-17 17:39:30', ' ', '', '', 'publish', 'closed', 'closed', '', '38', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=38', 5, 'nav_menu_item', '', 0),
(39, 1, '2017-03-18 00:39:30', '2017-03-17 17:39:30', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=39', 6, 'nav_menu_item', '', 0),
(40, 1, '2017-03-18 00:39:30', '2017-03-17 17:39:30', ' ', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=40', 7, 'nav_menu_item', '', 0),
(41, 1, '2017-03-18 00:39:30', '2017-03-17 17:39:30', ' ', '', '', 'publish', 'closed', 'closed', '', '41', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=41', 8, 'nav_menu_item', '', 0),
(42, 1, '2017-03-18 00:39:30', '2017-03-17 17:39:30', ' ', '', '', 'publish', 'closed', 'closed', '', '42', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=42', 12, 'nav_menu_item', '', 0),
(43, 1, '2017-03-18 00:39:30', '2017-03-17 17:39:30', '', 'Hướng dẫn mua hàng', '', 'publish', 'closed', 'closed', '', 'huong-dan-mua-hang', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=43', 16, 'nav_menu_item', '', 0),
(44, 1, '2017-03-18 00:39:30', '2017-03-17 17:39:30', '', 'Liên hệ', '', 'publish', 'closed', 'closed', '', 'lien-he', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=44', 20, 'nav_menu_item', '', 0),
(47, 1, '2017-03-18 00:41:03', '2017-03-17 17:41:03', '{"flatsome::type_headings":{"value":{"font-family":"Roboto","variant":"500"},"type":"theme_mod","user_id":1},"flatsome::type_texts":{"value":{"font-family":"Roboto","variant":"regular"},"type":"theme_mod","user_id":1},"flatsome::type_size":{"value":"100","type":"theme_mod","user_id":1},"flatsome::type_nav":{"value":{"font-family":"Roboto","variant":"regular"},"type":"theme_mod","user_id":1},"flatsome::type_alt":{"value":{"font-family":"Roboto"},"type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '9b1f5a71-8698-4b8f-a716-79b39548f803', '', '', '2017-03-18 00:41:03', '2017-03-17 17:41:03', '', 0, 'http://localhost/flatsome/?p=47', 0, 'customize_changeset', '', 0),
(48, 1, '2017-03-18 00:43:50', '2017-03-17 17:43:50', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2017-03-18 00:43:50', '2017-03-17 17:43:50', '', 0, 'http://localhost/flatsome/wp-content/uploads/2017/03/logo.png', 0, 'attachment', 'image/png', 0),
(50, 1, '2017-03-18 00:51:55', '2017-03-17 17:51:55', '{"flatsome::type_headings":{"value":{"font-family":"Roboto","variant":"700"},"type":"theme_mod","user_id":1},"flatsome::type_alt":{"value":{"font-family":"Roboto","variant":"regular"},"type":"theme_mod","user_id":1},"flatsome::type_nav":{"value":{"font-family":"Roboto","variant":"700"},"type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'd2756561-857c-46f7-adf7-4b7318d4a967', '', '', '2017-03-18 00:51:55', '2017-03-17 17:51:55', '', 0, 'http://localhost/flatsome/?p=50', 0, 'customize_changeset', '', 0),
(51, 1, '2017-03-18 00:53:59', '2017-03-17 17:53:59', '', 'Asus', '', 'publish', 'closed', 'closed', '', 'asus', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=51', 9, 'nav_menu_item', '', 0),
(52, 1, '2017-03-18 00:53:59', '2017-03-17 17:53:59', '', 'Lenovo', '', 'publish', 'closed', 'closed', '', 'lenovo', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=52', 10, 'nav_menu_item', '', 0),
(53, 1, '2017-03-18 00:53:59', '2017-03-17 17:53:59', '', 'Acer', '', 'publish', 'closed', 'closed', '', 'acer', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=53', 11, 'nav_menu_item', '', 0),
(54, 1, '2017-03-18 00:53:59', '2017-03-17 17:53:59', '', 'Samsung Tablet', '', 'publish', 'closed', 'closed', '', 'samsung-tablet', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=54', 13, 'nav_menu_item', '', 0),
(55, 1, '2017-03-18 00:53:59', '2017-03-17 17:53:59', '', 'Ipad', '', 'publish', 'closed', 'closed', '', 'ipad', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=55', 14, 'nav_menu_item', '', 0),
(56, 1, '2017-03-18 00:53:59', '2017-03-17 17:53:59', '', 'Lenovo', '', 'publish', 'closed', 'closed', '', 'lenovo-2', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/flatsome/?p=56', 15, 'nav_menu_item', '', 0),
(57, 1, '2017-03-18 01:06:59', '2017-03-17 18:06:59', '{"flatsome::grid_style":{"value":"grid1","type":"theme_mod","user_id":1},"flatsome::category_shadow":{"value":"0","type":"theme_mod","user_id":1},"flatsome::category_shadow_hover":{"value":"0","type":"theme_mod","user_id":1},"flatsome::add_to_cart_style":{"value":"outline","type":"theme_mod","user_id":1},"flatsome::sale_bubble_percentage":{"value":true,"type":"theme_mod","user_id":1},"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #08c;\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #08c\\n}","type":"custom_css","user_id":1},"flatsome::color_primary":{"value":"#0088cc","type":"theme_mod","user_id":1},"flatsome::color_secondary":{"value":"#ff9200","type":"theme_mod","user_id":1},"flatsome::color_links":{"value":"#0088cc","type":"theme_mod","user_id":1},"flatsome::color_links_hover":{"value":"#1e73be","type":"theme_mod","user_id":1},"flatsome::category_title_style":{"value":"featured","type":"theme_mod","user_id":1},"flatsome::category_header_transparent":{"value":false,"type":"theme_mod","user_id":1},"flatsome::breadcrumb_size":{"value":"small","type":"theme_mod","user_id":1},"flatsome::header_top_height":{"value":"30","type":"theme_mod","user_id":1},"flatsome::topbar_bg":{"value":"#0088cc","type":"theme_mod","user_id":1},"flatsome::nav_height_bottom":{"value":"16","type":"theme_mod","user_id":1},"flatsome::category_row_count_tablet":{"value":"3","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'fa11cc23-e5ff-450c-a135-453f835ca2f8', '', '', '2017-03-18 01:06:59', '2017-03-17 18:06:59', '', 0, 'http://localhost/flatsome/?p=57', 0, 'customize_changeset', '', 0),
(58, 1, '2017-03-18 01:06:59', '2017-03-17 18:06:59', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #ea3a3c;\n}\n.gallery-col .box-image {\npadding: 10px 0\n}\n.badge-container {\nmargin-top: 10px; left: 0px; font-size: 14px;\n}\n.is-outline {\ncolor: #ea3a3c\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-size: 17px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #ea3a3c;\ncolor: #fff;\npadding: 12px 12px;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 1px 8px;\nborder-top: none;\n}\n.main-home-row { margin-top: 0px !important }\n\n\n\n\n', 'flatsome', '', 'publish', 'closed', 'closed', '', 'flatsome', '', '', '2017-04-03 22:43:33', '2017-04-03 15:43:33', '', 0, 'http://localhost/flatsome/flatsome/', 0, 'custom_css', '', 0),
(59, 1, '2017-03-18 01:06:59', '2017-03-17 18:06:59', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #08c;\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #08c\n}', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-03-18 01:06:59', '2017-03-17 18:06:59', '', 58, 'http://localhost/flatsome/58-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2017-03-18 10:32:39', '2017-03-18 03:32:39', '{"flatsome::topbar_left":{"value":"<strong class=\\"uppercase\\">Website \\u0111i\\u1ec7n t\\u1eed \\u0111i\\u1ec7n m\\u00e1y<\\/strong>","type":"theme_mod","user_id":1},"flatsome::category_title_style":{"value":"featured-center","type":"theme_mod","user_id":1},"flatsome::category_row_count_mobile":{"value":"2","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '7992e70a-7e86-48c7-a41e-bd10d1c1409a', '', '', '2017-03-18 10:32:39', '2017-03-18 03:32:39', '', 0, 'http://localhost/flatsome/?p=60', 0, 'customize_changeset', '', 0),
(61, 1, '2017-03-18 12:38:49', '2017-03-18 05:38:49', '{"flatsome::header_height":{"value":"100","type":"theme_mod","user_id":1},"flatsome::nav_size":{"value":"medium","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'b3d8d16c-5312-4583-98cf-e5f7751f4a7a', '', '', '2017-03-18 12:38:49', '2017-03-18 05:38:49', '', 0, 'http://localhost/flatsome/?p=61', 0, 'customize_changeset', '', 0),
(62, 1, '2017-03-18 12:45:16', '2017-03-18 05:45:16', '', 'xiaomi', '', 'inherit', 'open', 'closed', '', 'xiaomi', '', '', '2017-03-18 12:45:16', '2017-03-18 05:45:16', '', 0, 'http://localhost/flatsome/wp-content/uploads/2017/03/xiaomi.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2017-03-18 12:51:50', '2017-03-18 05:51:50', '', 'banner-1', '', 'inherit', 'open', 'closed', '', 'banner-1', '', '', '2017-03-18 12:51:50', '2017-03-18 05:51:50', '', 0, 'http://localhost/flatsome/wp-content/uploads/2017/03/banner-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(64, 1, '2017-03-18 12:53:29', '2017-03-18 05:53:29', '[section bg_color="rgb(241, 241, 241)" padding="8px" margin="15px"]\n\n[row style="collapse" col_style="dashed"]\n\n[col span="4" span__sm="12" padding="0px 15px 0px 15px" align="center"]\n\n[featured_box img="8687" img_width="20" pos="left" margin="px px px px"]\n\n<p><span style="font-size: 90%;"><strong>Free Delivery</strong> World Wide* <a href="#">Learn more</a></span></p>\n\n[/featured_box]\n\n[/col]\n[col span="4" span__sm="12" padding="0px 15px 0px 15px"]\n\n[featured_box img="8686" img_width="20" pos="left" margin="px px px px"]\n\n<p><span style="font-size: 90%;">Loved by our Customers. <strong>5000+</strong> Reviews</span></p>\n\n[/featured_box]\n\n[/col]\n[col span="4" span__sm="12" padding="0px 15px 0px 15px"]\n\n[featured_box img="8685" img_width="20" pos="left" margin="px px px px"]\n\n<p><span style="font-size: 90%;"><strong>Free Returns</strong> and <strong>Free Shipping</strong></span></p>\n\n[/featured_box]\n\n[/col]\n\n[/row]\n\n[/section]\n[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="63" image_size="original"]\n\n[ux_image id="62" image_size="original" margin="-80px 0px 0px 0px"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="Our BestSellers" size="undefined" link_text="Browse All" link="#"]\n\n[ux_products columns="5" products="6" orderby="sales"]\n\n[title text="Latest on Sale" size="undefined" link_text="Browse all" link="#"]\n\n[ux_products columns="5" orderby="sales" show="onsale"]\n\n[title text="Weekly Featured Products" size="undefined" link_text="Browse all" link="#"]\n\n[ux_products columns="5" products="6"]\n\n[gap height="50px"]\n\n[ux_banner height="399px" bg="7460" bg_overlay="rgba(0, 0, 0, 0.08)" bg_pos="53% 43%" parallax="3"]\n\n[text_box width="58" width__sm="80" position_x="50" position_y="50"]\n\n<h2 class="uppercase"><strong>Sale Ends Soon</strong></h2>\n<h4 class="lead uppercase">Up to <strong>50% off</strong> selected products</h4>\n[ux_countdown bg_color="rgba(255, 255, 255, 0.23)"]\n\n[button text="Browse now"]\n\n\n[/text_box]\n\n[/ux_banner]\n[gap height="44px"]\n\n[ux_product_categories style="bounce" image_height="107%"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-03-18 12:53:29', '2017-03-18 05:53:29', '', 2, 'http://localhost/flatsome/2-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2017-03-18 12:57:17', '2017-03-18 05:57:17', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="63" image_size="original"]\n\n[ux_image id="62" image_size="original" margin="-80px 0px 0px 0px"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products columns="5" products="6" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products columns="5" orderby="sales" show="onsale"]\n\n[title text="NỔI BẬT TRONG TUẦN" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products columns="5" products="6"]\n\n[gap height="50px"]\n\n[ux_banner height="399px" bg="7460" bg_overlay="rgba(0, 0, 0, 0.08)" bg_pos="53% 43%" parallax="3"]\n\n[text_box width="58" width__sm="80" position_x="50" position_y="50"]\n\n<h2 class="uppercase"><strong>DEAL GIÁ SỐC</strong></h2>\n<h4 class="lead uppercase">Giảm tới <strong>50%</strong> tất cả các sản phẩm</h4>\n[ux_countdown bg_color="rgba(255, 255, 255, 0.23)"]\n\n[button text="xem ngay"]\n\n\n[/text_box]\n\n[/ux_banner]\n[gap height="44px"]\n\n[ux_product_categories style="bounce" image_height="107%"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-03-18 12:57:17', '2017-03-18 05:57:17', '', 2, 'http://localhost/flatsome/2-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2017-03-18 13:02:29', '2017-03-18 06:02:29', '', 'banner-DEAL', '', 'inherit', 'open', 'closed', '', 'banner-deal', '', '', '2017-03-18 13:02:29', '2017-03-18 06:02:29', '', 0, 'http://localhost/flatsome/wp-content/uploads/2017/03/banner-DEAL.png', 0, 'attachment', 'image/png', 0),
(69, 1, '2017-03-18 13:03:53', '2017-03-18 06:03:53', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="63" image_size="original"]\n\n[ux_image id="62" image_size="original" margin="-80px 0px 0px 0px"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products columns="5" products="6" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products columns="5" orderby="sales" show="onsale"]\n\n[title text="NỔI BẬT TRONG TUẦN" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products columns="5" products="6"]\n\n[gap height="50px"]\n\n[ux_banner height="399px" bg="68" bg_overlay="rgba(0, 0, 0, 0.08)" bg_pos="53% 43%" parallax="3"]\n\n[text_box width="58" width__sm="80" position_x="50" position_y="50"]\n\n<h2 class="uppercase"><strong>GIỜ VÀNG GIÁ SỐC</strong></h2>\n<h4 class="lead uppercase">Giảm tới <strong>50%</strong> tất cả các sản phẩm điện thoại</h4>\n[ux_countdown bg_color="#FF9200" year="2017"]\n\n[button text="MUA NGAY"]\n\n\n[/text_box]\n\n[/ux_banner]\n[gap height="44px"]\n\n[ux_product_categories style="bounce" image_height="107%"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-03-18 13:03:53', '2017-03-18 06:03:53', '', 2, 'http://localhost/flatsome/2-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2017-03-18 13:19:25', '2017-03-18 06:19:25', '', 'smart-watch', '', 'inherit', 'open', 'closed', '', 'smart-watch', '', '', '2017-03-18 13:19:25', '2017-03-18 06:19:25', '', 0, 'http://localhost/flatsome/wp-content/uploads/2017/03/smart-watch.jpg', 0, 'attachment', 'image/jpeg', 0),
(72, 1, '2017-03-18 13:30:45', '2017-03-18 06:30:45', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="63" image_size="original"]\n\n[ux_image id="62" image_size="original" margin="-80px 0px 0px 0px"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="6" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" orderby="sales" show="onsale"]\n\n[title text="NỔI BẬT TRONG TUẦN" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="6"]\n\n[gap height="50px"]\n\n[ux_banner height="399px" bg="68" bg_overlay="rgba(0, 0, 0, 0.08)" bg_pos="53% 43%" parallax="3"]\n\n[text_box width="58" width__sm="80" position_x="50" position_y="50"]\n\n<h2 class="uppercase"><strong>GIỜ VÀNG GIÁ SỐC</strong></h2>\n<h4 class="lead uppercase">Giảm tới <strong>50%</strong> tất cả các sản phẩm điện thoại</h4>\n[ux_countdown bg_color="#FF9200" year="2017"]\n\n[button text="MUA NGAY"]\n\n\n[/text_box]\n\n[/ux_banner]\n[gap height="44px"]\n\n[ux_product_categories style="normal" type="row" image_height="107%"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-03-18 13:30:45', '2017-03-18 06:30:45', '', 2, 'http://localhost/flatsome/2-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2017-03-18 13:31:52', '2017-03-18 06:31:52', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="63" image_size="original"]\n\n[ux_image id="62" image_size="original" margin="-80px 0px 0px 0px"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="6" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" orderby="sales" show="onsale"]\n\n[title text="NỔI BẬT TRONG TUẦN" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="6"]\n\n[gap height="50px"]\n\n[ux_banner height="399px" bg="68" bg_overlay="rgba(0, 0, 0, 0.08)" bg_pos="53% 43%" parallax="3"]\n\n[text_box width="58" width__sm="80" position_x="50" position_y="50"]\n\n<h2 class="uppercase"><strong>GIỜ VÀNG GIÁ SỐC</strong></h2>\n<h4 class="lead uppercase">Giảm tới <strong>50%</strong> tất cả các sản phẩm điện thoại</h4>\n[ux_countdown bg_color="#FF9200" year="2017"]\n\n[button text="MUA NGAY"]\n\n\n[/text_box]\n\n[/ux_banner]\n[gap height="44px"]\n\n[ux_product_categories style="normal" type="row" image_height="107%"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-03-18 13:31:52', '2017-03-18 06:31:52', '', 2, 'http://localhost/flatsome/2-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2017-03-18 13:32:25', '2017-03-18 06:32:25', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="63" image_size="original"]\n\n[ux_image id="62" image_size="original" margin="-80px 0px 0px 0px"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="6" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5" orderby="sales" show="onsale"]\n\n[title text="NỔI BẬT TRONG TUẦN" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="6"]\n\n[gap height="50px"]\n\n[ux_banner height="399px" bg="68" bg_overlay="rgba(0, 0, 0, 0.08)" bg_pos="53% 43%" parallax="3"]\n\n[text_box width="58" width__sm="80" position_x="50" position_y="50"]\n\n<h2 class="uppercase"><strong>GIỜ VÀNG GIÁ SỐC</strong></h2>\n<h4 class="lead uppercase">Giảm tới <strong>50%</strong> tất cả các sản phẩm điện thoại</h4>\n[ux_countdown bg_color="#FF9200" year="2017"]\n\n[button text="MUA NGAY"]\n\n\n[/text_box]\n\n[/ux_banner]\n[gap height="44px"]\n\n[ux_product_categories style="normal" type="row" image_height="107%"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-03-18 13:32:25', '2017-03-18 06:32:25', '', 2, 'http://localhost/flatsome/2-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2017-03-18 13:33:04', '2017-03-18 06:33:04', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="63" image_size="original"]\n\n[ux_image id="62" image_size="original" margin="-80px 0px 0px 0px"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5" orderby="sales" show="onsale"]\n\n[title text="NỔI BẬT TRONG TUẦN" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5"]\n\n[gap height="50px"]\n\n[ux_banner height="399px" bg="68" bg_overlay="rgba(0, 0, 0, 0.08)" bg_pos="53% 43%" parallax="3"]\n\n[text_box width="58" width__sm="80" position_x="50" position_y="50"]\n\n<h2 class="uppercase"><strong>GIỜ VÀNG GIÁ SỐC</strong></h2>\n<h4 class="lead uppercase">Giảm tới <strong>50%</strong> tất cả các sản phẩm điện thoại</h4>\n[ux_countdown bg_color="#FF9200" year="2017"]\n\n[button text="MUA NGAY"]\n\n\n[/text_box]\n\n[/ux_banner]\n[gap height="44px"]\n\n[ux_product_categories style="normal" type="row" image_height="107%"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-03-18 13:33:04', '2017-03-18 06:33:04', '', 2, 'http://localhost/flatsome/2-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2017-03-18 15:01:27', '2017-03-18 08:01:27', '{"flatsome::footer_left_text":{"value":"<div style=\\"padding-top: 15px\\">Copyright [ux_current_year] &copy; <strong>UX Themes<\\/strong><\\/div>","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'd39dbc73-d7f0-4e97-94db-5bae33b693cf', '', '', '2017-03-18 15:01:27', '2017-03-18 08:01:27', '', 0, 'http://localhost/flatsome/d39dbc73-d7f0-4e97-94db-5bae33b693cf/', 0, 'customize_changeset', '', 0),
(78, 1, '2017-03-18 15:01:52', '2017-03-18 08:01:52', '[]', '', '', 'trash', 'closed', 'closed', '', 'efbcf577-9383-49de-82ca-d2ace0384016', '', '', '2017-03-18 15:01:52', '2017-03-18 08:01:52', '', 0, 'http://localhost/flatsome/efbcf577-9383-49de-82ca-d2ace0384016/', 0, 'customize_changeset', '', 0),
(79, 1, '2017-03-18 15:08:09', '2017-03-18 08:08:09', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="63" image_size="original"]\n\n[ux_image id="62" image_size="original" margin="-80px 0px 0px 0px"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5" orderby="sales" show="onsale"]\n\n[title text="NỔI BẬT TRONG TUẦN" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5"]\n\n[gap height="50px"]\n\n[ux_banner height="399px" bg="68" bg_overlay="rgba(0, 0, 0, 0.08)" bg_pos="53% 43%" parallax="3"]\n\n[text_box width="58" width__sm="80" position_x="50" position_y="50"]\n\n<h2 class="uppercase"><strong>GIỜ VÀNG GIÁ SỐC</strong></h2>\n<h4 class="lead uppercase">Giảm tới <strong>50%</strong> tất cả các sản phẩm điện thoại</h4>\n[ux_countdown bg_color="#FF9200" year="2017"]\n\n[button text="MUA NGAY" icon="icon-gift" icon_pos="left"]\n\n\n[/text_box]\n\n[/ux_banner]\n[gap height="44px"]\n\n[ux_product_categories style="normal" type="row" image_height="107%"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-03-18 15:08:09', '2017-03-18 08:08:09', '', 2, 'http://localhost/flatsome/2-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2017-03-18 15:11:24', '2017-03-18 08:11:24', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="63" image_size="original"]\n\n[ux_image id="62" image_size="original" margin="-80px 0px 0px 0px"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5" orderby="sales" show="onsale"]\n\n[title text="NỔI BẬT TRONG TUẦN" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5"]\n\n[gap height="50px"]\n\n[ux_banner height="399px" bg="68" bg_overlay="rgba(0, 0, 0, 0.08)" bg_pos="53% 43%" parallax="3"]\n\n[text_box width="58" width__sm="80" position_x="50" position_y="50"]\n\n<h2 class="uppercase"><strong>GIỜ VÀNG GIÁ SỐC</strong></h2>\n<h4 class="lead uppercase">Giảm tới <strong>50%</strong> tất cả các sản phẩm điện thoại</h4>\n[ux_countdown bg_color="#FF9200" year="2017"]\n\n[button text="MUA NGAY" icon="icon-heart" icon_pos="left"]\n\n\n[/text_box]\n\n[/ux_banner]\n[gap height="44px"]\n\n[ux_product_categories style="normal" type="row" image_height="107%"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-03-18 15:11:24', '2017-03-18 08:11:24', '', 2, 'http://localhost/flatsome/2-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2017-03-18 15:16:22', '2017-03-18 08:16:22', '{"flatsome::footer_left_text":{"value":"<div style=\\"padding-top: 15px\\"><a href=\\"http:\\/\\/vifonic.vn\\/\\" target=\\"_blank\\">Thi\\u1ebft k\\u1ebf web<\\/a> b\\u1edfi <strong>Vifonic.vn<\\/strong><\\/div>","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '004bea2e-f612-4db7-a136-05139795ab59', '', '', '2017-03-18 15:16:22', '2017-03-18 08:16:22', '', 0, 'http://localhost/flatsome/?p=81', 0, 'customize_changeset', '', 0),
(83, 1, '2017-03-18 15:22:22', '2017-03-18 08:22:22', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #08c;\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #08c\n}\n.widget {\nmargin-bottom: 50px\n}', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-03-18 15:22:22', '2017-03-18 08:22:22', '', 58, 'http://localhost/flatsome/58-revision-v1/', 0, 'revision', '', 0),
(84, 1, '2017-03-22 01:32:19', '2017-03-21 18:32:19', '{"flatsome::type_headings":{"value":{"font-family":"Roboto","variant":"regular"},"type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'c333c7ac-0cee-438c-9afb-c6e49ee229ad', '', '', '2017-03-22 01:32:19', '2017-03-21 18:32:19', '', 0, 'http://localhost/flatsome/?p=84', 0, 'customize_changeset', '', 0),
(86, 1, '2017-04-03 14:16:20', '0000-00-00 00:00:00', '', 'Lưu bản nháp tự động', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-04-03 14:16:20', '0000-00-00 00:00:00', '', 0, 'http://localhost/thietbidien/?p=86', 0, 'post', '', 0),
(87, 1, '2017-04-03 14:57:32', '2017-04-03 07:57:32', '{"flatsome::preset_demo":{"value":"header-wide-nav","type":"theme_mod","user_id":1},"flatsome::topbar_elements_right":{"value":["nav-top","social"],"type":"theme_mod","user_id":1},"flatsome::header_elements_left":{"value":["search-form"],"type":"theme_mod","user_id":1},"flatsome::header_elements_bottom_left":{"value":["nav"],"type":"theme_mod","user_id":1},"flatsome::logo_width":{"value":"166","type":"theme_mod","user_id":1},"flatsome::topbar_show":{"value":true,"type":"theme_mod","user_id":1},"flatsome::topbar_bg":{"value":"#eeeeee","type":"theme_mod","user_id":1},"flatsome::header_height":{"value":"91","type":"theme_mod","user_id":1},"flatsome::header_bg_img_repeat":{"value":"repeat-x","type":"theme_mod","user_id":1},"flatsome::box_shadow_header":{"value":false,"type":"theme_mod","user_id":1},"flatsome::nav_size":{"value":"","type":"theme_mod","user_id":1},"flatsome::nav_uppercase":{"value":true,"type":"theme_mod","user_id":1},"flatsome::header_bg_transparent_shade":{"value":false,"type":"theme_mod","user_id":1},"flatsome::header_bottom_height":{"value":"43","type":"theme_mod","user_id":1},"flatsome::nav_position_bg":{"value":"#424242","type":"theme_mod","user_id":1},"flatsome::nav_uppercase_bottom":{"value":true,"type":"theme_mod","user_id":1},"flatsome::nav_position_color":{"value":"dark","type":"theme_mod","user_id":1},"flatsome::mobile_sidebar":{"value":["search-form","nav","account","html-2","html-3"],"type":"theme_mod","user_id":1},"flatsome::topbar_color":{"value":"light","type":"theme_mod","user_id":1},"flatsome::topbar_left":{"value":"<strong class=\\"uppercase\\">Th\\u0103ng Long Tech<\\/strong>","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '5db7ace6-042b-4396-b10a-3ab5460d7369', '', '', '2017-04-03 14:57:32', '2017-04-03 07:57:32', '', 0, 'http://localhost/thietbidien/?p=87', 0, 'customize_changeset', '', 0),
(88, 1, '2017-04-03 14:58:45', '2017-04-03 07:58:45', '{"flatsome::nav_position_bg":{"value":"#da0301","type":"theme_mod","user_id":1},"flatsome::header_bottom_height":{"value":"44","type":"theme_mod","user_id":1},"flatsome::nav_size_bottom":{"value":"medium","type":"theme_mod","user_id":1},"flatsome::type_nav_bottom_color":{"value":"#ffffff","type":"theme_mod","user_id":1},"flatsome::type_nav_bottom_color_hover":{"value":"#e0ff20","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '62f31376-6209-4ef0-be6a-eb2e01e4c59e', '', '', '2017-04-03 14:58:45', '2017-04-03 07:58:45', '', 0, 'http://localhost/thietbidien/?p=88', 0, 'customize_changeset', '', 0),
(89, 1, '2017-04-03 15:01:02', '0000-00-00 00:00:00', '{"flatsome::dropdown_border":{"value":"#ffffff","type":"theme_mod","user_id":1},"flatsome::dropdown_nav_size":{"value":"100","type":"theme_mod","user_id":1},"flatsome::header_elements_left":{"value":[],"type":"theme_mod","user_id":1},"flatsome::header_elements_bottom_right":{"value":["search"],"type":"theme_mod","user_id":1},"flatsome::color_primary":{"value":"#da0301","type":"theme_mod","user_id":1},"flatsome::color_secondary":{"value":"#111111","type":"theme_mod","user_id":1},"flatsome::color_success":{"value":"#0088cc","type":"theme_mod","user_id":1},"flatsome::color_links":{"value":"#da0301","type":"theme_mod","user_id":1},"flatsome::color_links_hover":{"value":"#111111","type":"theme_mod","user_id":1}}', '', '', 'auto-draft', 'closed', 'closed', '', 'dc672050-2007-4fad-8aff-45efebf17532', '', '', '2017-04-03 15:01:02', '2017-04-03 08:01:02', '', 0, 'http://localhost/thietbidien/?p=89', 0, 'customize_changeset', '', 0),
(90, 1, '2017-04-03 15:01:39', '2017-04-03 08:01:39', '[]', '', '', 'trash', 'closed', 'closed', '', '0fc98078-cb98-4b84-b252-d846a814dbd5', '', '', '2017-04-03 15:01:39', '2017-04-03 08:01:39', '', 0, 'http://localhost/thietbidien/0fc98078-cb98-4b84-b252-d846a814dbd5/', 0, 'customize_changeset', '', 0),
(91, 1, '2017-04-03 15:02:29', '2017-04-03 08:02:29', '{"flatsome::logo_width":{"value":"250","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'be6f2a1e-9cb5-4b94-8ded-178d275cf6f9', '', '', '2017-04-03 15:02:29', '2017-04-03 08:02:29', '', 0, 'http://localhost/thietbidien/?p=91', 0, 'customize_changeset', '', 0),
(92, 1, '2017-04-03 15:05:52', '2017-04-03 08:05:52', '{"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #08c;\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #08c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.nav > li > a {\\nfont-size: 16px;\\nmargin-right: 7px;\\n}","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '9dce5a72-7f3c-4ba7-82c8-7fe3027d699a', '', '', '2017-04-03 15:05:52', '2017-04-03 08:05:52', '', 0, 'http://localhost/thietbidien/?p=92', 0, 'customize_changeset', '', 0),
(93, 1, '2017-04-03 15:05:52', '2017-04-03 08:05:52', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #08c;\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #08c\n}\n.widget {\nmargin-bottom: 50px\n}\n.nav > li > a {\nfont-size: 16px;\nmargin-right: 7px;\n}', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 15:05:52', '2017-04-03 08:05:52', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(94, 1, '2017-04-03 15:07:41', '2017-04-03 08:07:41', '{"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #08c;\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #08c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '1938f418-127f-4cde-b9a5-64d59d623aec', '', '', '2017-04-03 15:07:41', '2017-04-03 08:07:41', '', 0, 'http://localhost/thietbidien/1938f418-127f-4cde-b9a5-64d59d623aec/', 0, 'customize_changeset', '', 0),
(95, 1, '2017-04-03 15:07:41', '2017-04-03 08:07:41', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #08c;\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #08c\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 15:07:41', '2017-04-03 08:07:41', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2017-04-03 15:07:42', '0000-00-00 00:00:00', '{"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #08c;\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #08c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}","type":"custom_css","user_id":1}}', '', '', 'auto-draft', 'closed', 'closed', '', '1938f418-127f-4cde-b9a5-64d59d623aec', '', '', '2017-04-03 15:07:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/thietbidien/?p=96', 0, 'customize_changeset', '', 0),
(97, 1, '2017-04-03 15:08:09', '2017-04-03 08:08:09', '{"flatsome::header_height_sticky":{"value":"30","type":"theme_mod","user_id":1},"flatsome::sticky_logo_padding":{"value":"0","type":"theme_mod","user_id":1},"flatsome::nav_height_sticky":{"value":"50","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '5fe9cc47-9e47-4fd2-8fcd-8831a0cc490f', '', '', '2017-04-03 15:08:09', '2017-04-03 08:08:09', '', 0, 'http://localhost/thietbidien/5fe9cc47-9e47-4fd2-8fcd-8831a0cc490f/', 0, 'customize_changeset', '', 0),
(98, 1, '2017-04-03 15:08:20', '2017-04-03 08:08:20', '{"flatsome::header_sticky":{"value":false,"type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '1bbb1559-ca3b-4a08-9319-bff0f7aa2c80', '', '', '2017-04-03 15:08:20', '2017-04-03 08:08:20', '', 0, 'http://localhost/thietbidien/1bbb1559-ca3b-4a08-9319-bff0f7aa2c80/', 0, 'customize_changeset', '', 0),
(99, 1, '2017-04-03 15:08:21', '0000-00-00 00:00:00', '{"flatsome::header_sticky":{"value":false,"type":"theme_mod","user_id":1}}', '', '', 'auto-draft', 'closed', 'closed', '', '1bbb1559-ca3b-4a08-9319-bff0f7aa2c80', '', '', '2017-04-03 15:08:21', '0000-00-00 00:00:00', '', 0, 'http://localhost/thietbidien/?p=99', 0, 'customize_changeset', '', 0),
(100, 1, '2017-04-03 15:08:29', '2017-04-03 08:08:29', '[]', '', '', 'trash', 'closed', 'closed', '', '003fcf34-3ffb-4fbc-a648-7220d7bbd0e2', '', '', '2017-04-03 15:08:29', '2017-04-03 08:08:29', '', 0, 'http://localhost/thietbidien/003fcf34-3ffb-4fbc-a648-7220d7bbd0e2/', 0, 'customize_changeset', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(101, 1, '2017-04-03 15:13:42', '2017-04-03 08:13:42', '', 'slide', '', 'inherit', 'open', 'closed', '', 'slide', '', '', '2017-04-03 15:13:42', '2017-04-03 08:13:42', '', 0, 'http://localhost/thietbidien/wp-content/uploads/2017/04/slide.png', 0, 'attachment', 'image/png', 0),
(102, 1, '2017-04-03 15:17:14', '2017-04-03 08:17:14', '', 'slider2', '', 'inherit', 'open', 'closed', '', 'slider2', '', '', '2017-04-03 15:17:14', '2017-04-03 08:17:14', '', 0, 'http://localhost/thietbidien/wp-content/uploads/2017/04/slider2.jpg', 0, 'attachment', 'image/jpeg', 0),
(103, 1, '2017-04-03 15:31:58', '2017-04-03 08:31:58', '{"flatsome::nav_height_bottom":{"value":"24","type":"theme_mod","user_id":1},"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #08c;\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #08c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-weight: 600; font-size: 16px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #DA0301;\\ncolor: #fff;\\npadding: 12px 12px;\\nfont-weight: 600;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 8px;\\nborder-top: none;\\n}\\n\\n\\n\\n\\n","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '0d682bb8-c9c1-4bc7-8e65-089534e886c5', '', '', '2017-04-03 15:31:58', '2017-04-03 08:31:58', '', 0, 'http://localhost/thietbidien/?p=103', 0, 'customize_changeset', '', 0),
(104, 1, '2017-04-03 15:31:13', '2017-04-03 08:31:13', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n[ux_image id="102" image_size="original" height="56.25%" margin="-80px 0px 0px 0px"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5" orderby="sales" show="onsale"]\n\n[title text="NỔI BẬT TRONG TUẦN" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" columns="5" products="5"]\n\n[gap height="50px"]\n\n[ux_banner height="399px" bg="68" bg_overlay="rgba(0, 0, 0, 0.08)" bg_pos="53% 43%" parallax="3"]\n\n[text_box width="58" width__sm="80" position_x="50" position_y="50"]\n\n<h2 class="uppercase"><strong>GIỜ VÀNG GIÁ SỐC</strong></h2>\n<h4 class="lead uppercase">Giảm tới <strong>50%</strong> tất cả các sản phẩm điện thoại</h4>\n[ux_countdown bg_color="#FF9200" year="2017"]\n\n[button text="MUA NGAY" icon="icon-heart" icon_pos="left"]\n\n\n[/text_box]\n\n[/ux_banner]\n[gap height="44px"]\n\n[ux_product_categories style="normal" type="row" image_height="107%"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-03 15:31:13', '2017-04-03 08:31:13', '', 2, 'http://localhost/thietbidien/2-revision-v1/', 0, 'revision', '', 0),
(105, 1, '2017-04-03 15:31:58', '2017-04-03 08:31:58', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #08c;\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #08c\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-weight: 600; font-size: 16px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #DA0301;\ncolor: #fff;\npadding: 12px 12px;\nfont-weight: 600;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 8px;\nborder-top: none;\n}\n\n\n\n\n', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 15:31:58', '2017-04-03 08:31:58', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(106, 1, '2017-04-03 15:36:49', '2017-04-03 08:36:49', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales" show="onsale"]\n\n[title text="SẢN PHẨM NỔI BẬT" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-03 15:36:49', '2017-04-03 08:36:49', '', 2, 'http://localhost/thietbidien/2-revision-v1/', 0, 'revision', '', 0),
(107, 1, '2017-04-03 15:39:59', '2017-04-03 08:39:59', '', '1', '', 'inherit', 'open', 'closed', '', '1', '', '', '2017-04-03 15:39:59', '2017-04-03 08:39:59', '', 0, 'http://localhost/thietbidien/wp-content/uploads/2017/04/1.png', 0, 'attachment', 'image/png', 0),
(108, 1, '2017-04-03 15:40:01', '2017-04-03 08:40:01', '', '2', '', 'inherit', 'open', 'closed', '', '2', '', '', '2017-04-03 15:40:01', '2017-04-03 08:40:01', '', 0, 'http://localhost/thietbidien/wp-content/uploads/2017/04/2.png', 0, 'attachment', 'image/png', 0),
(109, 1, '2017-04-03 15:40:03', '2017-04-03 08:40:03', '', '3', '', 'inherit', 'open', 'closed', '', '3', '', '', '2017-04-03 15:40:03', '2017-04-03 08:40:03', '', 0, 'http://localhost/thietbidien/wp-content/uploads/2017/04/3.png', 0, 'attachment', 'image/png', 0),
(110, 1, '2017-04-03 15:40:04', '2017-04-03 08:40:04', '', '4', '', 'inherit', 'open', 'closed', '', '4', '', '', '2017-04-03 15:40:04', '2017-04-03 08:40:04', '', 0, 'http://localhost/thietbidien/wp-content/uploads/2017/04/4.png', 0, 'attachment', 'image/png', 0),
(111, 1, '2017-04-03 15:41:14', '2017-04-03 08:41:14', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales" show="onsale"]\n\n[title text="SẢN PHẨM NỔI BẬT" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]\n\n[title text="ĐỐI TÁC" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_gallery ids="107,108,109,110" type="slider" image_size="original"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-03 15:41:14', '2017-04-03 08:41:14', '', 2, 'http://localhost/thietbidien/2-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(112, 1, '2017-04-03 15:41:27', '2017-04-03 08:41:27', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales" show="onsale"]\n\n[title text="SẢN PHẨM NỔI BẬT" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]\n\n[title text="ĐỐI TÁC"]\n\n[ux_gallery ids="107,108,109,110" type="slider" image_size="original"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-03 15:41:27', '2017-04-03 08:41:27', '', 2, 'http://localhost/thietbidien/2-revision-v1/', 0, 'revision', '', 0),
(113, 1, '2017-04-03 15:42:03', '2017-04-03 08:42:03', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales" show="onsale"]\n\n[title text="SẢN PHẨM NỔI BẬT" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]\n\n[gap height="20px"]\n\n[title text="ĐỐI TÁC"]\n\n[ux_gallery ids="107,108,109,110" type="slider" image_size="original"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-03 15:42:03', '2017-04-03 08:42:03', '', 2, 'http://localhost/thietbidien/2-revision-v1/', 0, 'revision', '', 0),
(114, 1, '2017-04-03 15:44:03', '2017-04-03 08:44:03', '', '5', '', 'inherit', 'open', 'closed', '', '5', '', '', '2017-04-03 15:44:03', '2017-04-03 08:44:03', '', 0, 'http://localhost/thietbidien/wp-content/uploads/2017/04/5.png', 0, 'attachment', 'image/png', 0),
(115, 1, '2017-04-03 15:46:17', '2017-04-03 08:46:17', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales" show="onsale"]\n\n[title text="SẢN PHẨM NỔI BẬT" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]\n\n[gap height="20px"]\n\n[title text="ĐỐI TÁC"]\n\n[ux_gallery ids="107,108,109,110,114" style="default" lightbox="false" type="slider" slider_nav_style="simple" slider_nav_position="outside" slider_bullets="true" image_size="original" text_align="center" text_size="xlarge"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-03 15:46:17', '2017-04-03 08:46:17', '', 2, 'http://localhost/thietbidien/2-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2017-04-03 15:47:44', '2017-04-03 08:47:44', '{"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #DA0301;\\n}\\n.gallery-col .box-image {\\npadding: 10px 0\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #08c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-weight: 600; font-size: 16px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #DA0301;\\ncolor: #fff;\\npadding: 12px 12px;\\nfont-weight: 600;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 8px;\\nborder-top: none;\\n}\\n\\n\\n\\n\\n","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'c537998a-66d7-47cd-8205-a549f54c1dc7', '', '', '2017-04-03 15:47:44', '2017-04-03 08:47:44', '', 0, 'http://localhost/thietbidien/?p=116', 0, 'customize_changeset', '', 0),
(117, 1, '2017-04-03 15:47:44', '2017-04-03 08:47:44', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #DA0301;\n}\n.gallery-col .box-image {\npadding: 10px 0\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #08c\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-weight: 600; font-size: 16px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #DA0301;\ncolor: #fff;\npadding: 12px 12px;\nfont-weight: 600;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 8px;\nborder-top: none;\n}\n\n\n\n\n', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 15:47:44', '2017-04-03 08:47:44', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(118, 1, '2017-04-03 15:48:45', '2017-04-03 08:48:45', '{"flatsome::color_secondary":{"value":"#0088cc","type":"theme_mod","user_id":1},"flatsome::color_success":{"value":"#81d742","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'e5d4fffa-e038-4e88-95e1-f18737a1d6db', '', '', '2017-04-03 15:48:45', '2017-04-03 08:48:45', '', 0, 'http://localhost/thietbidien/e5d4fffa-e038-4e88-95e1-f18737a1d6db/', 0, 'customize_changeset', '', 0),
(119, 1, '2017-04-03 15:48:46', '0000-00-00 00:00:00', '{"flatsome::color_secondary":{"value":"#0088cc","type":"theme_mod","user_id":1},"flatsome::color_success":{"value":"#81d742","type":"theme_mod","user_id":1}}', '', '', 'auto-draft', 'closed', 'closed', '', 'e5d4fffa-e038-4e88-95e1-f18737a1d6db', '', '', '2017-04-03 15:48:46', '0000-00-00 00:00:00', '', 0, 'http://localhost/thietbidien/?p=119', 0, 'customize_changeset', '', 0),
(120, 1, '2017-04-03 15:50:20', '2017-04-03 08:50:20', '{"flatsome::footer_2_bg_color":{"value":"#23282d","type":"theme_mod","user_id":1},"flatsome::footer_bottom_color":{"value":"#222222","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'e2e9e441-6945-4733-a172-584ab7e3c08d', '', '', '2017-04-03 15:50:20', '2017-04-03 08:50:20', '', 0, 'http://localhost/thietbidien/e2e9e441-6945-4733-a172-584ab7e3c08d/', 0, 'customize_changeset', '', 0),
(121, 1, '2017-04-03 15:53:59', '2017-04-03 08:53:59', '{"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #DA0301;\\n}\\n.gallery-col .box-image {\\npadding: 10px 0\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #DA0301\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-weight: 600; font-size: 16px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #DA0301;\\ncolor: #fff;\\npadding: 12px 12px;\\nfont-weight: 600;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 8px;\\nborder-top: none;\\n}\\n\\n\\n\\n\\n","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '5e7a8917-51cf-4f0a-a948-0a81dc8a4c13', '', '', '2017-04-03 15:53:59', '2017-04-03 08:53:59', '', 0, 'http://localhost/thietbidien/?p=121', 0, 'customize_changeset', '', 0),
(122, 1, '2017-04-03 15:53:59', '2017-04-03 08:53:59', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #DA0301;\n}\n.gallery-col .box-image {\npadding: 10px 0\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #DA0301\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-weight: 600; font-size: 16px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #DA0301;\ncolor: #fff;\npadding: 12px 12px;\nfont-weight: 600;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 8px;\nborder-top: none;\n}\n\n\n\n\n', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 15:53:59', '2017-04-03 08:53:59', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(123, 1, '2017-04-03 16:51:41', '2017-04-03 09:51:41', '', 'P1', '', 'inherit', 'open', 'closed', '', 'p1', '', '', '2017-04-03 16:51:41', '2017-04-03 09:51:41', '', 31, 'http://localhost/thietbidien/wp-content/uploads/2017/03/P1.jpg', 0, 'attachment', 'image/jpeg', 0),
(124, 1, '2017-04-03 16:51:42', '2017-04-03 09:51:42', '', 'P2', '', 'inherit', 'open', 'closed', '', 'p2', '', '', '2017-04-03 16:51:42', '2017-04-03 09:51:42', '', 31, 'http://localhost/thietbidien/wp-content/uploads/2017/03/P2.jpg', 0, 'attachment', 'image/jpeg', 0),
(125, 1, '2017-04-03 16:51:44', '2017-04-03 09:51:44', '', 'P3', '', 'inherit', 'open', 'closed', '', 'p3', '', '', '2017-04-03 16:51:44', '2017-04-03 09:51:44', '', 31, 'http://localhost/thietbidien/wp-content/uploads/2017/03/P3.jpg', 0, 'attachment', 'image/jpeg', 0),
(126, 1, '2017-04-03 16:51:45', '2017-04-03 09:51:45', '', 'P4', '', 'inherit', 'open', 'closed', '', 'p4', '', '', '2017-04-03 16:51:45', '2017-04-03 09:51:45', '', 31, 'http://localhost/thietbidien/wp-content/uploads/2017/03/P4.jpg', 0, 'attachment', 'image/jpeg', 0),
(127, 1, '2017-04-03 16:51:47', '2017-04-03 09:51:47', '', 'P6', '', 'inherit', 'open', 'closed', '', 'p6', '', '', '2017-04-03 16:51:47', '2017-04-03 09:51:47', '', 31, 'http://localhost/thietbidien/wp-content/uploads/2017/03/P6.jpg', 0, 'attachment', 'image/jpeg', 0),
(128, 1, '2017-04-03 16:51:48', '2017-04-03 09:51:48', '', 'P7', '', 'inherit', 'open', 'closed', '', 'p7', '', '', '2017-04-03 16:51:48', '2017-04-03 09:51:48', '', 31, 'http://localhost/thietbidien/wp-content/uploads/2017/03/P7.jpg', 0, 'attachment', 'image/jpeg', 0),
(129, 1, '2017-04-03 16:53:37', '2017-04-03 09:53:37', '', 'Bộ dụng cụ tone', '', 'inherit', 'closed', 'closed', '', '26-autosave-v1', '', '', '2017-04-03 16:53:37', '2017-04-03 09:53:37', '', 26, 'http://localhost/thietbidien/26-autosave-v1/', 0, 'revision', '', 0),
(130, 1, '2017-04-03 16:55:41', '2017-04-03 09:55:41', '', '', '', 'inherit', 'closed', 'closed', '', '20-autosave-v1', '', '', '2017-04-03 16:55:41', '2017-04-03 09:55:41', '', 20, 'http://localhost/thietbidien/20-autosave-v1/', 0, 'revision', '', 0),
(131, 1, '2017-04-03 16:55:42', '2017-04-03 09:55:42', '', 'Máy đánh bóng', '', 'inherit', 'closed', 'closed', '', '18-autosave-v1', '', '', '2017-04-03 16:55:42', '2017-04-03 09:55:42', '', 18, 'http://localhost/thietbidien/18-autosave-v1/', 0, 'revision', '', 0),
(132, 1, '2017-04-03 17:01:36', '2017-04-03 10:01:36', '{"flatsome::type_headings":{"value":{"font-family":"Roboto","variant":"500"},"type":"theme_mod","user_id":1},"flatsome::type_nav":{"value":{"font-family":"Roboto","variant":"500"},"type":"theme_mod","user_id":1},"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #DA0301;\\n}\\n.gallery-col .box-image {\\npadding: 10px 0\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #DA0301\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-weight: 600; font-size: 16px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #DA0301;\\ncolor: #fff;\\npadding: 12px 12px;\\nfont-weight: 500;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 8px;\\nborder-top: none;\\n}\\n\\n\\n\\n\\n","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'f242e9e5-fa40-473e-8f06-4402e34d53b2', '', '', '2017-04-03 17:01:36', '2017-04-03 10:01:36', '', 0, 'http://localhost/thietbidien/?p=132', 0, 'customize_changeset', '', 0),
(133, 1, '2017-04-03 17:01:36', '2017-04-03 10:01:36', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #DA0301;\n}\n.gallery-col .box-image {\npadding: 10px 0\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #DA0301\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-weight: 600; font-size: 16px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #DA0301;\ncolor: #fff;\npadding: 12px 12px;\nfont-weight: 500;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 8px;\nborder-top: none;\n}\n\n\n\n\n', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 17:01:36', '2017-04-03 10:01:36', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(134, 1, '2017-04-03 17:09:33', '2017-04-03 10:09:33', '{"flatsome::color_primary":{"value":"#ea3a3c","type":"theme_mod","user_id":1},"flatsome::color_alert":{"value":"#ea3a3c","type":"theme_mod","user_id":1},"flatsome::color_links":{"value":"#e74847","type":"theme_mod","user_id":1},"flatsome::color_secondary":{"value":"#ff9200","type":"theme_mod","user_id":1},"flatsome::color_texts":{"value":"#333333","type":"theme_mod","user_id":1},"flatsome::type_headings_color":{"value":"#111111","type":"theme_mod","user_id":1},"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #ea3a3c;\\n}\\n.gallery-col .box-image {\\npadding: 10px 0\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #ea3a3c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-weight: 600; font-size: 16px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #ea3a3c;\\ncolor: #fff;\\npadding: 12px 12px;\\nfont-weight: 500;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 8px;\\nborder-top: none;\\n}\\n\\n\\n\\n\\n","type":"custom_css","user_id":1},"flatsome::nav_position_bg":{"value":"#ea3a3c","type":"theme_mod","user_id":1},"flatsome::type_nav_bottom_color_hover":{"value":"#ffeba4","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '0e6aca75-c24d-4750-b7d5-48f18d07960c', '', '', '2017-04-03 17:09:33', '2017-04-03 10:09:33', '', 0, 'http://localhost/thietbidien/?p=134', 0, 'customize_changeset', '', 0),
(135, 1, '2017-04-03 17:09:33', '2017-04-03 10:09:33', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #ea3a3c;\n}\n.gallery-col .box-image {\npadding: 10px 0\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #ea3a3c\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-weight: 600; font-size: 16px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #ea3a3c;\ncolor: #fff;\npadding: 12px 12px;\nfont-weight: 500;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 8px;\nborder-top: none;\n}\n\n\n\n\n', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 17:09:33', '2017-04-03 10:09:33', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(136, 1, '2017-04-03 17:12:54', '2017-04-03 10:12:54', '{"flatsome::color_secondary":{"value":"#8bc34a","type":"theme_mod","user_id":1},"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #ea3a3c;\\n}\\n.gallery-col .box-image {\\npadding: 10px 0\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #ea3a3c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-weight: 600; font-size: 16px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #ea3a3c;\\ncolor: #fff;\\npadding: 12px 12px;\\nfont-weight: 500;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 8px;\\nborder-top: none;\\n}\\n\\n\\n\\n\\n\\n","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '3c4c9dc0-cd28-427c-9904-6a831bdf3331', '', '', '2017-04-03 17:12:54', '2017-04-03 10:12:54', '', 0, 'http://localhost/thietbidien/?p=136', 0, 'customize_changeset', '', 0),
(137, 1, '2017-04-03 17:15:43', '2017-04-03 10:15:43', '{"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #ea3a3c;\\n}\\n.gallery-col .box-image {\\npadding: 10px 0\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #ea3a3c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-weight: 500; font-size: 16px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #ea3a3c;\\ncolor: #fff;\\npadding: 12px 12px;\\nfont-weight: 500;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 8px;\\nborder-top: none;\\n}\\n\\n\\n\\n\\n\\n","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'c9bbf4db-fffe-4596-8c7b-736beee84793', '', '', '2017-04-03 17:15:43', '2017-04-03 10:15:43', '', 0, 'http://localhost/thietbidien/c9bbf4db-fffe-4596-8c7b-736beee84793/', 0, 'customize_changeset', '', 0),
(138, 1, '2017-04-03 17:15:43', '2017-04-03 10:15:43', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #ea3a3c;\n}\n.gallery-col .box-image {\npadding: 10px 0\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #ea3a3c\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-weight: 500; font-size: 16px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #ea3a3c;\ncolor: #fff;\npadding: 12px 12px;\nfont-weight: 500;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 8px;\nborder-top: none;\n}\n\n\n\n\n\n', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 17:15:43', '2017-04-03 10:15:43', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(139, 1, '2017-04-03 19:02:13', '2017-04-03 12:02:13', '{"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #ea3a3c;\\n}\\n.gallery-col .box-image {\\npadding: 10px 0\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #ea3a3c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-weight: 500; font-size: 16px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #ea3a3c;\\ncolor: #fff;\\npadding: 12px 12px;\\nfont-weight: 500;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 1px 8px;\\nborder-top: none;\\n}\\n\\n\\n\\n\\n\\n","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'fc3fe03a-9d44-44e7-9433-0ea2c73cf989', '', '', '2017-04-03 19:02:13', '2017-04-03 12:02:13', '', 0, 'http://localhost/thietbidien/?p=139', 0, 'customize_changeset', '', 0),
(140, 1, '2017-04-03 19:02:13', '2017-04-03 12:02:13', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #ea3a3c;\n}\n.gallery-col .box-image {\npadding: 10px 0\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #ea3a3c\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-weight: 500; font-size: 16px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #ea3a3c;\ncolor: #fff;\npadding: 12px 12px;\nfont-weight: 500;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 1px 8px;\nborder-top: none;\n}\n\n\n\n\n\n', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 19:02:13', '2017-04-03 12:02:13', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(141, 1, '2017-04-03 19:04:40', '2017-04-03 12:04:40', '[ux_banner_grid height="400"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[title text="sản phẩm bán chạy" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales" show="onsale"]\n\n[title text="SẢN PHẨM NỔI BẬT" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]\n\n[gap height="20px"]\n\n[title text="ĐỐI TÁC" size="90"]\n\n[ux_gallery ids="107,108,109,110,114" style="normal" lightbox="false" type="slider" col_spacing="small" slider_nav_style="simple" slider_nav_position="outside" slider_bullets="true" image_size="original" text_size="xsmall"]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-03 19:04:40', '2017-04-03 12:04:40', '', 2, 'http://localhost/thietbidien/2-revision-v1/', 0, 'revision', '', 0),
(142, 1, '2017-04-03 19:14:01', '2017-04-03 12:14:01', '[gap height="20px"]\n\n[ux_banner_grid height="380"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="102" image_size="original" height="56.25%" margin="0px 0px -20px 0px"]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[row style="small"]\n\n[col span="3" span__sm="12"]\n\n[ux_sidebar]\n\n\n[/col]\n[col span="9" span__sm="12"]\n\n[title text="sản phẩm bán chạy" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales" show="onsale"]\n\n[title text="SẢN PHẨM NỔI BẬT" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]\n\n[gap height="20px"]\n\n[title text="ĐỐI TÁC" size="90"]\n\n[ux_gallery ids="107,108,109,110,114" style="normal" lightbox="false" type="slider" col_spacing="small" slider_nav_style="simple" slider_nav_position="outside" slider_bullets="true" image_size="original" text_size="xsmall"]\n\n\n[/col]\n\n[/row]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-03 19:14:01', '2017-04-03 12:14:01', '', 2, 'http://localhost/thietbidien/2-revision-v1/', 0, 'revision', '', 0),
(143, 1, '2017-04-03 19:14:54', '2017-04-03 12:14:54', '{"widget_text[2]":{"value":{"encoded_serialized_instance":"YTozOntzOjU6InRpdGxlIjtzOjEwOiJMacOqbiBo4buHIjtzOjQ6InRleHQiO3M6MjQxOiJDw5RORyBUWSBUTkhIIEvhu7ggVEhV4bqsVCBUSMavxqBORyBN4bqgSSBBTiBDSOG6rkMgVEjhuq5ORw0KxJDhu4thIGNo4buJIDogMzMvMTYgUXXhu5FjIEjGsMahbmcsIFAuVGjhuqNvIMSQaeG7gW4sIFEuMiwgVFBIQ00NCsSQaeG7h24gdGhv4bqhaSA6IDA4IC0gMzUxOSA0MTgzICAgICAgICAgIEZheCA6IDA4IC0gMzUxOSA0MTcyDQpFbWFpbCA6IHNhbGVAYWN0Y29sLmNvbQ0KV2Vic2l0ZSA6IHd3dy5hY3Rjb2wuY29tIjtzOjY6ImZpbHRlciI7YjowO30=","title":"Li\\u00ean h\\u1ec7","is_widget_customizer_js_value":true,"instance_hash_key":"65377243c5c08345ba74030efe468009"},"type":"option","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '8bcb90d8-763f-4bc5-bce8-c13be86507f1', '', '', '2017-04-03 19:14:54', '2017-04-03 12:14:54', '', 0, 'http://localhost/thietbidien/?p=143', 0, 'customize_changeset', '', 0),
(144, 1, '2017-04-03 19:16:06', '2017-04-03 12:16:06', '{"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #ea3a3c;\\n}\\n.gallery-col .box-image {\\npadding: 10px 0\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #ea3a3c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-weight: 500; font-size: 16px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #ea3a3c;\\ncolor: #fff;\\npadding: 12px 12px;\\nfont-weight: 500;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 1px 8px;\\nborder-top: none;\\n}\\n#row-20654 { margin-top: 0px }\\n\\n\\n\\n\\n","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'aabebdab-e449-48c5-af5b-366a5b412505', '', '', '2017-04-03 19:16:06', '2017-04-03 12:16:06', '', 0, 'http://localhost/thietbidien/?p=144', 0, 'customize_changeset', '', 0),
(145, 1, '2017-04-03 19:16:06', '2017-04-03 12:16:06', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #ea3a3c;\n}\n.gallery-col .box-image {\npadding: 10px 0\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #ea3a3c\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-weight: 500; font-size: 16px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #ea3a3c;\ncolor: #fff;\npadding: 12px 12px;\nfont-weight: 500;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 1px 8px;\nborder-top: none;\n}\n#row-20654 { margin-top: 0px }\n\n\n\n\n', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 19:16:06', '2017-04-03 12:16:06', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(146, 1, '2017-04-03 19:17:21', '2017-04-03 12:17:21', '[gap height="20px"]\n\n[ux_banner_grid height="380"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="102" image_size="original" height="56.25%" margin="0px 0px -20px 0px"]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[row style="small" class="main-home-row"]\n\n[col span="3" span__sm="12"]\n\n[ux_sidebar]\n\n\n[/col]\n[col span="9" span__sm="12"]\n\n[title text="sản phẩm bán chạy" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales" show="onsale"]\n\n[title text="SẢN PHẨM NỔI BẬT" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]\n\n[gap height="20px"]\n\n[title text="ĐỐI TÁC" size="90"]\n\n[ux_gallery ids="107,108,109,110,114" style="normal" lightbox="false" type="slider" col_spacing="small" slider_nav_style="simple" slider_nav_position="outside" slider_bullets="true" image_size="original" text_size="xsmall"]\n\n\n[/col]\n\n[/row]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-03 19:17:21', '2017-04-03 12:17:21', '', 2, 'http://localhost/thietbidien/2-revision-v1/', 0, 'revision', '', 0),
(147, 1, '2017-04-03 19:18:00', '2017-04-03 12:18:00', '{"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #ea3a3c;\\n}\\n.gallery-col .box-image {\\npadding: 10px 0\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #ea3a3c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-weight: 500; font-size: 16px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #ea3a3c;\\ncolor: #fff;\\npadding: 12px 12px;\\nfont-weight: 500;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 1px 8px;\\nborder-top: none;\\n}\\n.main-home-row { margin-top: 0px }\\n\\n\\n\\n\\n","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'ebb7d29b-8bfe-4039-bb99-2d559b91ede8', '', '', '2017-04-03 19:18:00', '2017-04-03 12:18:00', '', 0, 'http://localhost/thietbidien/ebb7d29b-8bfe-4039-bb99-2d559b91ede8/', 0, 'customize_changeset', '', 0),
(148, 1, '2017-04-03 19:18:00', '2017-04-03 12:18:00', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #ea3a3c;\n}\n.gallery-col .box-image {\npadding: 10px 0\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #ea3a3c\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-weight: 500; font-size: 16px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #ea3a3c;\ncolor: #fff;\npadding: 12px 12px;\nfont-weight: 500;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 1px 8px;\nborder-top: none;\n}\n.main-home-row { margin-top: 0px }\n\n\n\n\n', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 19:18:00', '2017-04-03 12:18:00', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(149, 1, '2017-04-03 19:18:16', '2017-04-03 12:18:16', '{"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #ea3a3c;\\n}\\n.gallery-col .box-image {\\npadding: 10px 0\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px\\n}\\n.is-outline {\\ncolor: #ea3a3c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-weight: 500; font-size: 16px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #ea3a3c;\\ncolor: #fff;\\npadding: 12px 12px;\\nfont-weight: 500;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 1px 8px;\\nborder-top: none;\\n}\\n.main-home-row { margin-top: 0px !important }\\n\\n\\n\\n\\n","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'ae4994b6-04f3-4773-927b-069380b21f31', '', '', '2017-04-03 19:18:16', '2017-04-03 12:18:16', '', 0, 'http://localhost/thietbidien/ae4994b6-04f3-4773-927b-069380b21f31/', 0, 'customize_changeset', '', 0),
(150, 1, '2017-04-03 19:18:16', '2017-04-03 12:18:16', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #ea3a3c;\n}\n.gallery-col .box-image {\npadding: 10px 0\n}\n.badge-container {\nmargin-top: 10px; left: 0px\n}\n.is-outline {\ncolor: #ea3a3c\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-weight: 500; font-size: 16px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #ea3a3c;\ncolor: #fff;\npadding: 12px 12px;\nfont-weight: 500;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 1px 8px;\nborder-top: none;\n}\n.main-home-row { margin-top: 0px !important }\n\n\n\n\n', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 19:18:16', '2017-04-03 12:18:16', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(151, 1, '2017-04-03 19:25:41', '2017-04-03 12:25:41', '', 'thu-1', '', 'inherit', 'open', 'closed', '', 'thu-1', '', '', '2017-04-03 19:25:41', '2017-04-03 12:25:41', '', 0, 'http://localhost/thietbidien/wp-content/uploads/2017/04/thu-1.png', 0, 'attachment', 'image/png', 0),
(152, 1, '2017-04-03 19:26:41', '2017-04-03 12:26:41', '', '3706500', '', 'inherit', 'open', 'closed', '', '3706500', '', '', '2017-04-03 19:26:41', '2017-04-03 12:26:41', '', 0, 'http://localhost/thietbidien/wp-content/uploads/2017/04/3706500.png', 0, 'attachment', 'image/png', 0),
(153, 1, '2017-04-03 19:26:43', '2017-04-03 12:26:43', '', '5428271', '', 'inherit', 'open', 'closed', '', '5428271', '', '', '2017-04-03 19:26:43', '2017-04-03 12:26:43', '', 0, 'http://localhost/thietbidien/wp-content/uploads/2017/04/5428271.png', 0, 'attachment', 'image/png', 0),
(154, 1, '2017-04-03 19:26:46', '2017-04-03 12:26:46', '', 'thu-1', '', 'inherit', 'open', 'closed', '', 'thu-1-2', '', '', '2017-04-03 19:26:46', '2017-04-03 12:26:46', '', 0, 'http://localhost/thietbidien/wp-content/uploads/2017/04/thu-1-1.png', 0, 'attachment', 'image/png', 0),
(155, 1, '2017-04-03 19:26:57', '2017-04-03 12:26:57', '', '6090520', '', 'inherit', 'open', 'closed', '', '6090520', '', '', '2017-04-03 19:26:57', '2017-04-03 12:26:57', '', 0, 'http://localhost/thietbidien/wp-content/uploads/2017/04/6090520.png', 0, 'attachment', 'image/png', 0),
(156, 1, '2017-04-03 19:28:40', '2017-04-03 12:28:40', '[gap height="20px"]\n\n[ux_banner_grid height="380"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="102" image_size="original" height="56.25%" margin="0px 0px -20px 0px"]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[row style="small" class="main-home-row"]\n\n[col span="3" span__sm="12"]\n\n[ux_sidebar]\n\n\n[/col]\n[col span="9" span__sm="12"]\n\n[title text="Thư ủy nhiệm" size="90"]\n\n[ux_gallery ids="151,152,153,154,155" style="normal" lightbox="false" type="slider" col_spacing="small" slider_nav_style="simple" slider_nav_position="outside" slider_bullets="true"]\n\n[title text="sản phẩm bán chạy" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4" orderby="sales"]\n\n[title text="ĐANG GIẢM GIÁ" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales" show="onsale"]\n\n[title text="SẢN PHẨM NỔI BẬT" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]\n\n[gap height="20px"]\n\n[title text="ĐỐI TÁC" size="90"]\n\n[ux_gallery ids="107,108,109,110,114" style="normal" lightbox="false" type="slider" col_spacing="small" slider_nav_style="simple" slider_nav_position="outside" slider_bullets="true" image_size="original" text_size="xsmall"]\n\n\n[/col]\n\n[/row]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-03 19:28:40', '2017-04-03 12:28:40', '', 2, 'http://localhost/thietbidien/2-revision-v1/', 0, 'revision', '', 0),
(157, 1, '2017-04-03 21:02:39', '2017-04-03 14:02:39', '[gap height="20px"]\n\n[ux_banner_grid height="380"]\n\n[col_grid]\n\n[ux_slider]\n\n[ux_image id="102" image_size="original" height="56.25%" margin="0px 0px -20px 0px"]\n\n[ux_image id="102" image_size="original" height="56.25%"]\n\n\n[/ux_slider]\n\n[/col_grid]\n\n[/ux_banner_grid]\n[row style="small" class="main-home-row"]\n\n[col span="3" span__sm="12"]\n\n[ux_sidebar]\n\n\n[/col]\n[col span="9" span__sm="12"]\n\n[title text="Thư ủy nhiệm" size="90"]\n\n[ux_gallery ids="151,152,153,154,155" style="normal" lightbox="false" type="slider" col_spacing="small" slider_nav_style="simple" slider_nav_position="outside" slider_bullets="true"]\n\n[title text="Sản phẩm nổi bật" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales"]\n\n[title text="Thiết bị nâng hạ" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="8" orderby="sales" show="onsale"]\n\n[title text="Dụng cụ cầm tay" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]\n\n[title text="Dụng cụ đo" size="90" link_text="XEM TẤT CẢ" link="#"]\n\n[ux_products type="row" products="4"]\n\n[gap height="20px"]\n\n[title text="ĐỐI TÁC" size="90"]\n\n[ux_gallery ids="107,108,109,110,114" style="normal" lightbox="false" type="slider" col_spacing="small" slider_nav_style="simple" slider_nav_position="outside" slider_bullets="true" image_size="original" text_size="xsmall"]\n\n\n[/col]\n\n[/row]', 'Trang Chủ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2017-04-03 21:02:39', '2017-04-03 14:02:39', '', 2, 'http://localhost/thietbidien/2-revision-v1/', 0, 'revision', '', 0),
(158, 1, '2017-04-03 21:05:38', '2017-04-03 14:05:38', '', 'Giới thiệu', '', 'publish', 'closed', 'closed', '', 'gioi-thieu', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/thietbidien/?p=158', 2, 'nav_menu_item', '', 0),
(159, 1, '2017-04-03 21:05:39', '2017-04-03 14:05:39', '', 'Tin tức', '', 'publish', 'closed', 'closed', '', 'tin-tuc', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/thietbidien/?p=159', 18, 'nav_menu_item', '', 0),
(160, 1, '2017-04-03 21:05:39', '2017-04-03 14:05:39', '', 'Tuyển dụng', '', 'publish', 'closed', 'closed', '', 'tuyen-dung', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/thietbidien/?p=160', 19, 'nav_menu_item', '', 0),
(161, 1, '2017-04-03 21:06:55', '2017-04-03 14:06:55', ' ', '', '', 'publish', 'closed', 'closed', '', '161', '', '', '2017-04-03 21:06:55', '2017-04-03 14:06:55', '', 0, 'http://localhost/thietbidien/?p=161', 1, 'nav_menu_item', '', 0),
(162, 1, '2017-04-03 21:06:55', '2017-04-03 14:06:55', ' ', '', '', 'publish', 'closed', 'closed', '', '162', '', '', '2017-04-03 21:06:55', '2017-04-03 14:06:55', '', 0, 'http://localhost/thietbidien/?p=162', 3, 'nav_menu_item', '', 0),
(163, 1, '2017-04-03 21:06:55', '2017-04-03 14:06:55', ' ', '', '', 'publish', 'closed', 'closed', '', '163', '', '', '2017-04-03 21:06:55', '2017-04-03 14:06:55', '', 0, 'http://localhost/thietbidien/?p=163', 4, 'nav_menu_item', '', 0),
(164, 1, '2017-04-03 21:06:55', '2017-04-03 14:06:55', '', 'Giới thiệu', '', 'publish', 'closed', 'closed', '', 'gioi-thieu-2', '', '', '2017-04-03 21:06:55', '2017-04-03 14:06:55', '', 0, 'http://localhost/thietbidien/?p=164', 2, 'nav_menu_item', '', 0),
(165, 1, '2017-04-03 21:06:55', '2017-04-03 14:06:55', '', 'Liên hệ', '', 'publish', 'closed', 'closed', '', 'lien-he-2', '', '', '2017-04-03 21:06:55', '2017-04-03 14:06:55', '', 0, 'http://localhost/thietbidien/?p=165', 6, 'nav_menu_item', '', 0),
(166, 1, '2017-04-03 21:06:55', '2017-04-03 14:06:55', '', 'Tin tức', '', 'publish', 'closed', 'closed', '', 'tin-tuc-2', '', '', '2017-04-03 21:06:55', '2017-04-03 14:06:55', '', 0, 'http://localhost/thietbidien/?p=166', 5, 'nav_menu_item', '', 0),
(167, 1, '2017-04-03 21:08:41', '2017-04-03 14:08:41', ' ', '', '', 'publish', 'closed', 'closed', '', '167', '', '', '2017-04-03 21:08:41', '2017-04-03 14:08:41', '', 0, 'http://localhost/thietbidien/?p=167', 1, 'nav_menu_item', '', 0),
(168, 1, '2017-04-03 21:08:41', '2017-04-03 14:08:41', ' ', '', '', 'publish', 'closed', 'closed', '', '168', '', '', '2017-04-03 21:08:41', '2017-04-03 14:08:41', '', 0, 'http://localhost/thietbidien/?p=168', 2, 'nav_menu_item', '', 0),
(169, 1, '2017-04-03 21:08:41', '2017-04-03 14:08:41', ' ', '', '', 'publish', 'closed', 'closed', '', '169', '', '', '2017-04-03 21:08:41', '2017-04-03 14:08:41', '', 0, 'http://localhost/thietbidien/?p=169', 3, 'nav_menu_item', '', 0),
(170, 1, '2017-04-03 21:08:41', '2017-04-03 14:08:41', ' ', '', '', 'publish', 'closed', 'closed', '', '170', '', '', '2017-04-03 21:08:41', '2017-04-03 14:08:41', '', 0, 'http://localhost/thietbidien/?p=170', 4, 'nav_menu_item', '', 0),
(171, 1, '2017-04-03 21:08:41', '2017-04-03 14:08:41', ' ', '', '', 'publish', 'closed', 'closed', '', '171', '', '', '2017-04-03 21:08:41', '2017-04-03 14:08:41', '', 0, 'http://localhost/thietbidien/?p=171', 5, 'nav_menu_item', '', 0),
(172, 1, '2017-04-03 21:08:41', '2017-04-03 14:08:41', ' ', '', '', 'publish', 'closed', 'closed', '', '172', '', '', '2017-04-03 21:08:41', '2017-04-03 14:08:41', '', 0, 'http://localhost/thietbidien/?p=172', 6, 'nav_menu_item', '', 0),
(173, 1, '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 'Dịch vụ', '', 'publish', 'closed', 'closed', '', 'dich-vu', '', '', '2017-04-03 21:09:37', '2017-04-03 14:09:37', '', 0, 'http://localhost/thietbidien/?p=173', 17, 'nav_menu_item', '', 0),
(174, 1, '2017-04-03 21:10:41', '2017-04-03 14:10:41', '{"flatsome::topbar_elements_right":{"value":["languages","social"],"type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '69385896-d674-4dfa-a866-7d3b220d5bdc', '', '', '2017-04-03 21:10:41', '2017-04-03 14:10:41', '', 0, 'http://localhost/thietbidien/69385896-d674-4dfa-a866-7d3b220d5bdc/', 0, 'customize_changeset', '', 0),
(175, 1, '2017-04-03 21:10:42', '0000-00-00 00:00:00', '{"flatsome::topbar_elements_right":{"value":["languages","social"],"type":"theme_mod","user_id":1}}', '', '', 'auto-draft', 'closed', 'closed', '', '69385896-d674-4dfa-a866-7d3b220d5bdc', '', '', '2017-04-03 21:10:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/thietbidien/?p=175', 0, 'customize_changeset', '', 0),
(176, 1, '2017-04-03 21:11:41', '2017-04-03 14:11:41', '{"flatsome::logo_padding":{"value":"0","type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '8e69484f-32cb-4c36-9aab-c99904917057', '', '', '2017-04-03 21:11:41', '2017-04-03 14:11:41', '', 0, 'http://localhost/thietbidien/8e69484f-32cb-4c36-9aab-c99904917057/', 0, 'customize_changeset', '', 0),
(177, 1, '2017-04-03 21:11:42', '0000-00-00 00:00:00', '{"flatsome::logo_padding":{"value":"0","type":"theme_mod","user_id":1}}', '', '', 'auto-draft', 'closed', 'closed', '', '8e69484f-32cb-4c36-9aab-c99904917057', '', '', '2017-04-03 21:11:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/thietbidien/?p=177', 0, 'customize_changeset', '', 0),
(178, 1, '2017-04-03 21:43:29', '2017-04-03 14:43:29', '[]', '', '', 'trash', 'closed', 'closed', '', 'daa2059d-1c0e-463a-9ceb-e6758584db0d', '', '', '2017-04-03 21:43:29', '2017-04-03 14:43:29', '', 0, 'http://localhost/thietbidien/daa2059d-1c0e-463a-9ceb-e6758584db0d/', 0, 'customize_changeset', '', 0),
(179, 1, '2017-04-03 21:47:35', '2017-04-03 14:47:35', '{"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #ea3a3c;\\n}\\n.gallery-col .box-image {\\npadding: 10px 0\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px; font-size: 14px;\\n}\\n.is-outline {\\ncolor: #ea3a3c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-weight: 500; font-size: 16px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #ea3a3c;\\ncolor: #fff;\\npadding: 12px 12px;\\nfont-weight: 500;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 1px 8px;\\nborder-top: none;\\n}\\n.main-home-row { margin-top: 0px !important }\\n\\n\\n\\n\\n","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '39dd17d2-d4cb-4112-9735-4038fba4983a', '', '', '2017-04-03 21:47:35', '2017-04-03 14:47:35', '', 0, 'http://localhost/thietbidien/?p=179', 0, 'customize_changeset', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(180, 1, '2017-04-03 21:47:35', '2017-04-03 14:47:35', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #ea3a3c;\n}\n.gallery-col .box-image {\npadding: 10px 0\n}\n.badge-container {\nmargin-top: 10px; left: 0px; font-size: 14px;\n}\n.is-outline {\ncolor: #ea3a3c\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-weight: 500; font-size: 16px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #ea3a3c;\ncolor: #fff;\npadding: 12px 12px;\nfont-weight: 500;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 1px 8px;\nborder-top: none;\n}\n.main-home-row { margin-top: 0px !important }\n\n\n\n\n', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 21:47:35', '2017-04-03 14:47:35', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0),
(181, 1, '2017-04-03 21:56:40', '2017-04-03 14:56:40', 'Thị trường công nghiệp ô tô Hàn Quốc chững lại Thị trường công nghiệp ô tô Hàn Quốc chững lại Thị trường công nghiệp ô tô Hàn Quốc chững lại', 'Thị trường công nghiệp ô tô Hàn Quốc chững lại', '', 'publish', 'open', 'open', '', 'thi-truong-cong-nghiep-o-to-han-quoc-chung-lai', '', '', '2017-04-03 21:56:40', '2017-04-03 14:56:40', '', 0, 'http://localhost/thietbidien/?p=181', 0, 'post', '', 0),
(182, 1, '2017-04-03 21:56:22', '2017-04-03 14:56:22', '', '3', '', 'inherit', 'open', 'closed', '', '3-2', '', '', '2017-04-03 21:56:22', '2017-04-03 14:56:22', '', 181, 'http://localhost/thietbidien/wp-content/uploads/2017/04/3.jpg', 0, 'attachment', 'image/jpeg', 0),
(183, 1, '2017-04-03 21:56:40', '2017-04-03 14:56:40', 'Thị trường công nghiệp ô tô Hàn Quốc chững lại Thị trường công nghiệp ô tô Hàn Quốc chững lại Thị trường công nghiệp ô tô Hàn Quốc chững lại', 'Thị trường công nghiệp ô tô Hàn Quốc chững lại', '', 'inherit', 'closed', 'closed', '', '181-revision-v1', '', '', '2017-04-03 21:56:40', '2017-04-03 14:56:40', '', 181, 'http://localhost/thietbidien/181-revision-v1/', 0, 'revision', '', 0),
(184, 1, '2017-04-03 21:58:10', '2017-04-03 14:58:10', '', 'Chiến lược của Vietnam Airlines', '', 'publish', 'open', 'open', '', 'chien-luoc-cua-vietnam-airlines', '', '', '2017-04-03 21:58:10', '2017-04-03 14:58:10', '', 0, 'http://localhost/thietbidien/?p=184', 0, 'post', '', 0),
(185, 1, '2017-04-03 21:58:03', '2017-04-03 14:58:03', '', 'banner-plane', '', 'inherit', 'open', 'closed', '', 'banner-plane', '', '', '2017-04-03 21:58:03', '2017-04-03 14:58:03', '', 184, 'http://localhost/thietbidien/wp-content/uploads/2017/04/banner-plane.jpg', 0, 'attachment', 'image/jpeg', 0),
(186, 1, '2017-04-03 21:58:10', '2017-04-03 14:58:10', '', 'Chiến lược của Vietnam Airlines', '', 'inherit', 'closed', 'closed', '', '184-revision-v1', '', '', '2017-04-03 21:58:10', '2017-04-03 14:58:10', '', 184, 'http://localhost/thietbidien/184-revision-v1/', 0, 'revision', '', 0),
(187, 1, '2017-04-03 22:01:32', '2017-04-03 15:01:32', '{"flatsome::category_row_count":{"value":"3","type":"theme_mod","user_id":1},"flatsome::product_box_category":{"value":false,"type":"theme_mod","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', '93bef16b-a96d-46e3-8acd-9e9ce07fa166', '', '', '2017-04-03 22:01:32', '2017-04-03 15:01:32', '', 0, 'http://localhost/thietbidien/?p=187', 0, 'customize_changeset', '', 0),
(188, 1, '2017-04-03 22:43:33', '2017-04-03 15:43:33', '{"flatsome::type_headings":{"value":{"font-family":"Roboto Condensed","variant":"700"},"type":"theme_mod","user_id":1},"flatsome::type_texts":{"value":{"font-family":"Roboto","variant":"regular"},"type":"theme_mod","user_id":1},"flatsome::type_size_mobile":{"value":"100","type":"theme_mod","user_id":1},"flatsome::type_nav":{"value":{"font-family":"Roboto Condensed","variant":"600"},"type":"theme_mod","user_id":1},"flatsome::type_alt":{"value":{"font-family":"Roboto","variant":"regular"},"type":"theme_mod","user_id":1},"flatsome::disable_fonts":{"value":false,"type":"theme_mod","user_id":1},"custom_css[flatsome]":{"value":"\\/*\\nB\\u1ea1n c\\u00f3 th\\u1ec3 th\\u00eam CSS \\u1edf \\u0111\\u00e2y.\\n\\nB\\u1ea5m bi\\u1ec3u t\\u01b0\\u1ee3ng tr\\u1ee3 gi\\u00fap ph\\u00eda tr\\u00ean \\u0111\\u1ec3 t\\u00ecm hi\\u1ec3u th\\u00eam.\\n*\\/\\n.box-image {\\nborder: solid 1px #ddd\\n}\\n.box-image:hover {\\nborder-color: #ea3a3c;\\n}\\n.gallery-col .box-image {\\npadding: 10px 0\\n}\\n.badge-container {\\nmargin-top: 10px; left: 0px; font-size: 14px;\\n}\\n.is-outline {\\ncolor: #ea3a3c\\n}\\n.widget {\\nmargin-bottom: 50px\\n}\\n.header-bottom-nav.nav > li > a {\\nfont-size: 15px;\\nmargin-right: 7px;\\n}\\n.widget-title { font-size: 17px !important; }\\n.widget_product_categories {\\nmargin-bottom: 40px;\\n}\\n.widget_product_categories h3.widget-title {\\nbackground: #ea3a3c;\\ncolor: #fff;\\npadding: 12px 12px;\\nmargin-bottom: 0px;\\n}\\n.widget_product_categories .is-divider.small {\\ndisplay: none;\\n}\\n.widget_product_categories > ul {\\nborder: solid 1px #ddd;\\npadding: 1px 8px;\\nborder-top: none;\\n}\\n.main-home-row { margin-top: 0px !important }\\n\\n\\n\\n\\n","type":"custom_css","user_id":1}}', '', '', 'trash', 'closed', 'closed', '', 'fbe10913-a49e-4187-a50e-44ad1b86d7a1', '', '', '2017-04-03 22:43:33', '2017-04-03 15:43:33', '', 0, 'http://localhost/thietbidien/?p=188', 0, 'customize_changeset', '', 0),
(189, 1, '2017-04-03 22:43:33', '2017-04-03 15:43:33', '/*\nBạn có thể thêm CSS ở đây.\n\nBấm biểu tượng trợ giúp phía trên để tìm hiểu thêm.\n*/\n.box-image {\nborder: solid 1px #ddd\n}\n.box-image:hover {\nborder-color: #ea3a3c;\n}\n.gallery-col .box-image {\npadding: 10px 0\n}\n.badge-container {\nmargin-top: 10px; left: 0px; font-size: 14px;\n}\n.is-outline {\ncolor: #ea3a3c\n}\n.widget {\nmargin-bottom: 50px\n}\n.header-bottom-nav.nav > li > a {\nfont-size: 15px;\nmargin-right: 7px;\n}\n.widget-title { font-size: 17px !important; }\n.widget_product_categories {\nmargin-bottom: 40px;\n}\n.widget_product_categories h3.widget-title {\nbackground: #ea3a3c;\ncolor: #fff;\npadding: 12px 12px;\nmargin-bottom: 0px;\n}\n.widget_product_categories .is-divider.small {\ndisplay: none;\n}\n.widget_product_categories > ul {\nborder: solid 1px #ddd;\npadding: 1px 8px;\nborder-top: none;\n}\n.main-home-row { margin-top: 0px !important }\n\n\n\n\n', 'flatsome', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2017-04-03 22:43:33', '2017-04-03 15:43:33', '', 58, 'http://localhost/thietbidien/58-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_social_users`
#

DROP TABLE IF EXISTS `wp_social_users`;


#
# Table structure of table `wp_social_users`
#

CREATE TABLE `wp_social_users` (
  `ID` int(11) NOT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `identifier` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  KEY `ID` (`ID`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_social_users`
#

#
# End of data contents of table `wp_social_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(16, 2, 0),
(16, 6, 0),
(16, 7, 0),
(18, 2, 0),
(18, 6, 0),
(18, 7, 0),
(18, 9, 0),
(20, 2, 0),
(20, 6, 0),
(20, 8, 0),
(22, 2, 0),
(22, 6, 0),
(22, 9, 0),
(24, 2, 0),
(24, 10, 0),
(24, 11, 0),
(24, 13, 0),
(24, 16, 0),
(24, 17, 0),
(24, 18, 0),
(24, 19, 0),
(26, 2, 0),
(26, 11, 0),
(26, 13, 0),
(28, 2, 0),
(28, 11, 0),
(28, 13, 0),
(30, 2, 0),
(30, 8, 0),
(30, 10, 0),
(30, 13, 0),
(31, 2, 0),
(31, 6, 0),
(31, 8, 0),
(31, 11, 0),
(31, 14, 0),
(31, 15, 0),
(31, 16, 0),
(35, 12, 0),
(36, 12, 0),
(37, 12, 0),
(38, 12, 0),
(39, 12, 0),
(40, 12, 0),
(41, 12, 0),
(42, 12, 0),
(43, 12, 0),
(44, 12, 0),
(51, 12, 0),
(52, 12, 0),
(53, 12, 0),
(54, 12, 0),
(55, 12, 0),
(56, 12, 0),
(158, 12, 0),
(159, 12, 0),
(160, 12, 0),
(161, 20, 0),
(162, 20, 0),
(163, 20, 0),
(164, 20, 0),
(165, 20, 0),
(166, 20, 0),
(167, 21, 0),
(168, 21, 0),
(169, 21, 0),
(170, 21, 0),
(171, 21, 0),
(172, 21, 0),
(173, 12, 0),
(181, 1, 0),
(184, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 3),
(2, 2, 'product_type', '', 0, 9),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 0),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_cat', '', 0, 5),
(7, 7, 'product_cat', '', 0, 2),
(8, 8, 'product_cat', '', 0, 3),
(9, 9, 'product_cat', '', 0, 2),
(10, 10, 'product_cat', '', 0, 2),
(11, 11, 'product_cat', '', 0, 4),
(12, 12, 'nav_menu', '', 0, 20),
(13, 13, 'product_cat', '', 0, 4),
(14, 14, 'product_tag', '', 0, 1),
(15, 15, 'product_tag', '', 0, 1),
(16, 16, 'product_tag', '', 0, 2),
(17, 17, 'product_tag', '', 0, 1),
(18, 18, 'product_tag', '', 0, 1),
(19, 19, 'product_tag', '', 0, 1),
(20, 20, 'nav_menu', '', 0, 6),
(21, 21, 'nav_menu', '', 0, 6) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#
INSERT INTO `wp_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 6, 'order', '0'),
(2, 7, 'order', '0'),
(3, 6, 'product_count_product_cat', '5'),
(4, 7, 'product_count_product_cat', '2'),
(5, 8, 'order', '0'),
(6, 8, 'product_count_product_cat', '3'),
(7, 9, 'order', '0'),
(8, 9, 'product_count_product_cat', '2'),
(9, 9, 'cat_meta', 'a:2:{s:10:"cat_header";s:0:"";s:10:"cat_footer";s:0:"";}'),
(10, 9, 'display_type', ''),
(11, 9, 'thumbnail_id', '0'),
(12, 10, 'order', '0'),
(13, 10, 'display_type', ''),
(14, 10, 'thumbnail_id', '0'),
(15, 10, 'product_count_product_cat', '2'),
(16, 11, 'order', '0'),
(17, 11, 'product_count_product_cat', '4'),
(18, 13, 'order', '0'),
(19, 13, 'display_type', ''),
(20, 13, 'thumbnail_id', '0'),
(21, 13, 'cat_meta', 'a:2:{s:10:"cat_header";s:0:"";s:10:"cat_footer";s:0:"";}'),
(22, 13, 'product_count_product_cat', '4'),
(23, 6, 'cat_meta', 'a:2:{s:10:"cat_header";s:0:"";s:10:"cat_footer";s:0:"";}'),
(24, 11, 'cat_meta', 'a:2:{s:10:"cat_header";s:0:"";s:10:"cat_footer";s:0:"";}'),
(25, 10, 'cat_meta', 'a:2:{s:10:"cat_header";s:0:"";s:10:"cat_footer";s:0:"";}'),
(26, 6, 'display_type', ''),
(27, 6, 'thumbnail_id', '0'),
(28, 11, 'display_type', ''),
(29, 11, 'thumbnail_id', '0'),
(30, 14, 'product_count_product_tag', '1'),
(31, 15, 'product_count_product_tag', '1'),
(32, 16, 'product_count_product_tag', '2'),
(33, 17, 'product_count_product_tag', '1'),
(34, 18, 'product_count_product_tag', '1'),
(35, 19, 'product_count_product_tag', '1'),
(36, 7, 'cat_meta', 'a:2:{s:10:"cat_header";s:0:"";s:10:"cat_footer";s:0:"";}'),
(37, 8, 'cat_meta', 'a:2:{s:10:"cat_header";s:0:"";s:10:"cat_footer";s:0:"";}'),
(38, 7, 'display_type', ''),
(39, 7, 'thumbnail_id', '0'),
(40, 8, 'display_type', ''),
(41, 8, 'thumbnail_id', '0') ;

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Tin tức', 'tin-tuc', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'Thiết bị nâng hạ', 'thiet-bi-nang-ha', 0),
(7, 'Vật liệu sơn', 'vat-lieu-son', 0),
(8, 'Dụng cụ kẹp', 'dung-cu-kep', 0),
(9, 'Hóa chất công nghiệp', 'hoa-chat-cong-nghiep', 0),
(10, 'Thiết bị điện', 'thiet-bi-dien', 0),
(11, 'Dụng cụ cầm tay', 'dung-cu-cam-tay', 0),
(12, 'Main Menu', 'main-menu', 0),
(13, 'Dụng cụ đo', 'dung-cu-do', 0),
(14, 'samsung', 'samsung', 0),
(15, 'galaxy', 'galaxy', 0),
(16, 'điện thoại', 'dien-thoai', 0),
(17, 'apple', 'apple', 0),
(18, 'ipad', 'ipad', 0),
(19, 'tablet', 'tablet', 0),
(20, 'Footer Menu 1', 'footer-menu-1', 0),
(21, 'Footer Menu 2', 'footer-menu-2', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '0'),
(15, 1, 'session_tokens', 'a:1:{s:64:"1b135bdb2d0ad4a14241d2d86d923bf2d39c21ec4f2f43034b9d6b0ef2d41467";a:4:{s:10:"expiration";i:1492759876;s:2:"ip";s:3:"::1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36";s:5:"login";i:1491550276;}}'),
(16, 1, 'wp_dashboard_quick_press_last_post_id', '86'),
(17, 1, 'closedpostboxes_dashboard', 'a:4:{i:0;s:19:"dashboard_right_now";i:1;s:18:"dashboard_activity";i:2;s:36:"woocommerce_dashboard_recent_reviews";i:3;s:28:"woocommerce_dashboard_status";}'),
(18, 1, 'metaboxhidden_dashboard', 'a:2:{i:0;s:21:"dashboard_quick_press";i:1;s:17:"dashboard_primary";}'),
(19, 1, 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:38:"dashboard_right_now,dashboard_activity";s:4:"side";s:105:"dashboard_quick_press,dashboard_primary,woocommerce_dashboard_recent_reviews,woocommerce_dashboard_status";s:7:"column3";s:0:"";s:7:"column4";s:0:"";}'),
(20, 1, 'manageedit-shop_ordercolumnshidden', 'a:1:{i:0;s:15:"billing_address";}'),
(21, 1, 'wp_user-settings', 'libraryContent=browse'),
(22, 1, 'wp_user-settings-time', '1489771267'),
(23, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(24, 1, 'metaboxhidden_nav-menus', 'a:10:{i:0;s:20:"add-post-type-blocks";i:1;s:21:"add-post-type-product";i:2;s:27:"add-post-type-featured_item";i:3;s:12:"add-post_tag";i:4;s:15:"add-post_format";i:5;s:20:"add-block_categories";i:6;s:15:"add-product_tag";i:7;s:26:"add-featured_item_category";i:8;s:21:"add-featured_item_tag";i:9;s:30:"woocommerce_endpoints_nav_link";}'),
(25, 1, 'closedpostboxes_nav-menus', 'a:0:{}'),
(26, 1, 'nav_menu_recently_edited', '12') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BTN6Iacn2OqeGimRix5n3t2UVyx9nG/', 'admin', 'cuongiview@gmail.com', '', '2017-03-17 09:48:24', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_api_keys`
#

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;


#
# Table structure of table `wp_woocommerce_api_keys`
#

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `permissions` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8_unicode_ci NOT NULL,
  `nonces` longtext COLLATE utf8_unicode_ci,
  `truncated_key` char(7) COLLATE utf8_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_api_keys`
#

#
# End of data contents of table `wp_woocommerce_api_keys`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;


#
# Table structure of table `wp_woocommerce_attribute_taxonomies`
#

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `attribute_label` longtext COLLATE utf8_unicode_ci,
  `attribute_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `attribute_orderby` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_attribute_taxonomies`
#

#
# End of data contents of table `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `wp_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `download_id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(191),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_downloadable_product_permissions`
#

#
# End of data contents of table `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;


#
# Table structure of table `wp_woocommerce_order_itemmeta`
#

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_order_itemmeta`
#

#
# End of data contents of table `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_items`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;


#
# Table structure of table `wp_woocommerce_order_items`
#

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_name` longtext COLLATE utf8_unicode_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_order_items`
#

#
# End of data contents of table `wp_woocommerce_order_items`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokenmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;


#
# Table structure of table `wp_woocommerce_payment_tokenmeta`
#

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_payment_tokenmeta`
#

#
# End of data contents of table `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokens`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;


#
# Table structure of table `wp_woocommerce_payment_tokens`
#

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` text COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_payment_tokens`
#

#
# End of data contents of table `wp_woocommerce_payment_tokens`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_sessions`
#

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;


#
# Table structure of table `wp_woocommerce_sessions`
#

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `session_expiry` bigint(20) NOT NULL,
  PRIMARY KEY (`session_key`),
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_sessions`
#

#
# End of data contents of table `wp_woocommerce_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;


#
# Table structure of table `wp_woocommerce_shipping_zone_locations`
#

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) NOT NULL,
  `location_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type` (`location_type`),
  KEY `location_type_code` (`location_type`,`location_code`(90))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_locations`
#

#
# End of data contents of table `wp_woocommerce_shipping_zone_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_methods`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;


#
# Table structure of table `wp_woocommerce_shipping_zone_methods`
#

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) NOT NULL,
  `instance_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `method_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `method_order` bigint(20) NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_methods`
#

#
# End of data contents of table `wp_woocommerce_shipping_zone_methods`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zones`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;


#
# Table structure of table `wp_woocommerce_shipping_zones`
#

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `zone_order` bigint(20) NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_shipping_zones`
#

#
# End of data contents of table `wp_woocommerce_shipping_zones`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;


#
# Table structure of table `wp_woocommerce_tax_rate_locations`
#

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `location_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) NOT NULL,
  `location_type` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type` (`location_type`),
  KEY `location_type_code` (`location_type`,`location_code`(90))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_tax_rate_locations`
#

#
# End of data contents of table `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;


#
# Table structure of table `wp_woocommerce_tax_rates`
#

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`(191)),
  KEY `tax_rate_state` (`tax_rate_state`(191)),
  KEY `tax_rate_class` (`tax_rate_class`(191)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_tax_rates`
#

#
# End of data contents of table `wp_woocommerce_tax_rates`
# --------------------------------------------------------



#
# Delete any existing table `wp_yith_wcwl`
#

DROP TABLE IF EXISTS `wp_yith_wcwl`;


#
# Table structure of table `wp_yith_wcwl`
#

CREATE TABLE `wp_yith_wcwl` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `prod_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `wishlist_id` int(11) DEFAULT NULL,
  `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `prod_id` (`prod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_yith_wcwl`
#

#
# End of data contents of table `wp_yith_wcwl`
# --------------------------------------------------------



#
# Delete any existing table `wp_yith_wcwl_lists`
#

DROP TABLE IF EXISTS `wp_yith_wcwl_lists`;


#
# Table structure of table `wp_yith_wcwl_lists`
#

CREATE TABLE `wp_yith_wcwl_lists` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `wishlist_slug` varchar(200) NOT NULL,
  `wishlist_name` text,
  `wishlist_token` varchar(64) NOT NULL,
  `wishlist_privacy` tinyint(1) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `wishlist_token` (`wishlist_token`),
  KEY `wishlist_slug` (`wishlist_slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_yith_wcwl_lists`
#

#
# End of data contents of table `wp_yith_wcwl_lists`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

